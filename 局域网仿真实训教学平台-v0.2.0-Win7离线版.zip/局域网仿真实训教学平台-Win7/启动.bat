@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem ===== 可修改配置 =====
set "PORT=3000"
set "DATA_DIR=%~dp0data"
rem 密码校验等 CPU 任务交给线程池，多核机器可并行
set "UV_THREADPOOL_SIZE=8"
rem ======================

if /i "%PROCESSOR_ARCHITECTURE%"=="x86" (
  if exist "node-x86.exe" (set "NODE_EXE=node-x86.exe") else (set "NODE_EXE=node-x64.exe")
) else (
  if exist "node-x64.exe" (set "NODE_EXE=node-x64.exe") else (set "NODE_EXE=node-x86.exe")
)

echo.
echo  局域网仿真实训教学平台 v0.2.0 正在启动（%NODE_EXE%）...
echo  数据目录：%DATA_DIR%
echo  关闭本窗口即停止服务
echo.

"%NODE_EXE%" "dist\server\server.cjs"

echo.
echo  服务已停止。
pause
