﻿# ================================================================
#  易邮 Easymail · 局域网教学邮箱服务端  v1.6.3
#  新增：邮件转发（前端实现）、定时发送（服务端调度）、
#        自定义分类箱（可单独加密/解锁/改密/删除）、黑名单（收件拒收）
#  继承：v1.5 全部功能（星标/垃圾邮件/批量操作/转草稿重发等）
# ================================================================

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try {
    Add-Type -AssemblyName System.IO.Compression | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null
} catch {}

# ----------------------- 可配置区 -------------------------------
$StudentPort  = 8899
$TeacherPort  = 8898
$DefaultTeacherUser = 'admin'
$DefaultTeacherPwd  = 'admin'
$EmergencyResetCode = 'EMRESET-8888'
$DefaultDomain      = '163.com'
$MaxAttachCount = 5
$MaxAttachEach  = 200MB
$MaxAttachTotal = 500MB
$BlockedExt = @('.q6x6q')
$ImportDefaultPwd = '123456'
$ImportMaxRows    = 500
$MaxCustomBoxes   = 5      # 每人自定义分类箱上限
$MaxScheduled     = 20     # 每人定时发送任务上限
$MaxBlacklist     = 50     # 每人黑名单上限
$SchedMinSeconds  = 60     # 定时发送最早时间（秒）
$SchedMaxDays     = 7      # 定时发送最远时间（天）
$ForgotMaxFail  = 5      # 忘记密码验证失败次数上限（10 分钟内）
$ForgotLockMin  = 10     # 锁定时长（分钟）
# ----------------------------------------------------------------

$Root     = $PSScriptRoot
$DataFile = Join-Path $Root 'maildata.json'
$LogFile  = Join-Path $Root 'server.log'
$BoxNames = @('inbox','sent','draft','junk','trash')

$shaTmp = [System.Security.Cryptography.SHA256]::Create()
$Script:AesKey = $shaTmp.ComputeHash([System.Text.Encoding]::UTF8.GetBytes('EasyMail#Teaching#Server#2024'))
$shaTmp.Dispose()

$Script:Sessions    = @{}
$Script:Db          = $null
$Script:LastBackup  = [datetime]::MinValue
$Script:RepairInfo  = @{ nested = $false; filled = 0; dropped = 0; fixedBoxes = 0 }
$Script:Captchas    = @{}
$Script:SmsCodes    = @{}
$Script:CurDomain   = $DefaultDomain
$Script:ForgotLock  = @{ count = 0; until = [datetime]::MinValue }

# ----------------------- 通用工具 -------------------------------
function Write-Log([string]$msg, [string]$color = 'Gray') {
    $line = '[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $msg
    #Write-Host $line -ForegroundColor $color
    try { [System.IO.File]::AppendAllText($LogFile, $line + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false))) } catch {}
}

function Get-Now { return (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }

# 注意：本函数结果只允许【先赋值给变量】再使用，禁止直接接管道
function AsArray($x) {
    if ($null -eq $x) { return ,@() }
    if ($x -is [System.Array]) { return ,$x }
    if ($x -is [string]) { return ,@($x) }
    return ,@($x)
}
function Get-AnswerHash([string]$ans, [string]$salt) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h = [System.Text.Encoding]::UTF8.GetBytes($salt + '#' + $ans.Trim() + '#' + $salt)
        for ($i = 0; $i -lt 512; $i++) { $h = $sha.ComputeHash($h) }
        return [BitConverter]::ToString($h).Replace('-', '').ToLower()
    } finally { $sha.Dispose() }
}

function Get-PwdHash([string]$pwd, [string]$salt) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h = [System.Text.Encoding]::UTF8.GetBytes($salt + '|' + $pwd + '|' + $salt)
        for ($i = 0; $i -lt 1024; $i++) { $h = $sha.ComputeHash($h) }
        return [BitConverter]::ToString($h).Replace('-', '').ToLower()
    } finally { $sha.Dispose() }
}

# v1.5.2 加固：数组值原样返回（防止"只有1个元素"的数组在函数输出时被展开成标量）
function Get-PropSafe($obj, [string]$name, $default) {
    $v = $null
    $found = $false
    if ($null -ne $obj) {
        if ($obj -is [System.Collections.IDictionary]) {
            if ($obj.Contains($name)) { $v = $obj[$name]; $found = $true }
        } else {
            $p = $obj.PSObject.Properties[$name]
            if ($null -ne $p) { $v = $p.Value; $found = $true }
        }
    }
    if (-not $found) { $v = $default }
    if ($v -is [System.Array]) { return ,$v }
    return $v
}

function Ensure-Prop($obj, [string]$name, $default) {
    if ($null -eq $obj) { return }
    if ($obj -is [System.Collections.IDictionary]) {
        if (-not $obj.Contains($name)) { $obj[$name] = $default; $Script:RepairInfo.filled++ }
        return
    }
    $p = $obj.PSObject.Properties[$name]
    if ($null -eq $p) {
        Add-Member -InputObject $obj -MemberType NoteProperty -Name $name -Value $default -Force
        $Script:RepairInfo.filled++
    }
}

function Set-Prop($obj, [string]$name, $value) {
    if ($null -eq $obj) { return }
    if ($obj -is [System.Collections.IDictionary]) { $obj[$name] = $value; return }
    $p = $obj.PSObject.Properties[$name]
    if ($null -ne $p) { $p.Value = $value }
    else { Add-Member -InputObject $obj -MemberType NoteProperty -Name $name -Value $value -Force }
}

function Remove-Prop($obj, [string]$name) {
    if ($null -eq $obj) { return }
    if ($obj -is [System.Collections.IDictionary]) { try { $obj.Remove($name) | Out-Null } catch {}; return }
    $p = $obj.PSObject.Properties[$name]
    if ($null -ne $p) { $obj.PSObject.Properties.Remove($name) }
}

function Flatten-Deep([object]$list, [int]$maxLevel = 6) {
    $cur = $list
    for ($i = 0; $i -lt $maxLevel; $i++) {
        $items = @()
        if ($null -ne $cur) { $items = @($cur) }
        $hasNested = $false
        foreach ($it in $items) { if ($it -is [System.Array]) { $hasNested = $true; break } }
        if (-not $hasNested) { return ,$items }
        $flat = @()
        foreach ($it in $items) {
            if ($it -is [System.Array]) { $flat += @($it) } else { $flat += $it }
        }
        $cur = $flat
    }
    $out = @()
    foreach ($it in @($cur)) { if (-not ($it -is [System.Array])) { $out += $it } }
    return ,$out
}

function Get-DisplayAddr([string]$s) {
    $v = '' + $s
    if ($v.Trim() -eq '') { return $v }
    $out = @()
    foreach ($p in ($v -split ';')) {
        $t = $p.Trim()
        if ($t -eq '') { continue }
        if ($t -match '^([^@]+)@') { $out += ($Matches[1] + '@' + $Script:CurDomain) } else { $out += $t }
    }
    return ($out -join '; ')
}

# ----------------------- 图形验证码 -------------------------------
function New-CaptchaObject {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    $code = ''
    for ($i = 0; $i -lt 4; $i++) { $code += $chars[(Get-Random -Maximum $chars.Length)] }
    $noiseColors = @('#9bbf9b', '#7fae8e', '#a8c8a8', '#8fb99f')
    $textColors  = @('#2f6b45', '#0a8a54', '#3a7d54', '#1c5d34')
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<svg xmlns="http://www.w3.org/2000/svg" width="112" height="40" viewBox="0 0 112 40">')
    [void]$sb.Append('<rect width="112" height="40" fill="#eef6ee" stroke="#cfe0d2"/>')
    for ($i = 0; $i -lt 5; $i++) {
        $c = $noiseColors[(Get-Random -Maximum $noiseColors.Count)]
        [void]$sb.Append(('<line x1="{0}" y1="{1}" x2="{2}" y2="{3}" stroke="{4}" stroke-width="1"/>' -f (Get-Random -Maximum 112), (Get-Random -Minimum 4 -Maximum 36), (Get-Random -Maximum 112), (Get-Random -Minimum 4 -Maximum 36), $c))
    }
    $x = 10
    foreach ($ch in $code.ToCharArray()) {
        $y   = 29 + (Get-Random -Minimum -4 -Maximum 5)
        $rot = Get-Random -Minimum -28 -Maximum 29
        $fs  = 20 + (Get-Random -Minimum 0 -Maximum 6)
        $c   = $textColors[(Get-Random -Maximum $textColors.Count)]
        [void]$sb.Append(('<text x="{0}" y="{1}" font-size="{2}" font-family="Georgia, Times New Roman, serif" font-style="italic" font-weight="bold" fill="{3}" transform="rotate({4} {0} {1})">{5}</text>' -f $x, $y, $fs, $c, $rot, $ch))
        $x += 26
    }
    for ($i = 0; $i -lt 40; $i++) {
        [void]$sb.Append(('<circle cx="{0}" cy="{1}" r="0.9" fill="#88aa88" opacity="0.55"/>' -f (Get-Random -Maximum 112), (Get-Random -Maximum 40)))
    }
    [void]$sb.Append('</svg>')
    return @{ code = $code; svg = $sb.ToString() }
}

# ----------------------- 服务器设置 -------------------------------
function Get-ServerSettings {
    $cfg = Get-PropSafe $Script:Db 'settings' $null
    if ($null -eq $cfg) {
        $cfg = New-Object PSObject
        Set-Prop $Script:Db 'settings' $cfg
    }
    if ($null -eq (Get-PropSafe $cfg 'regCaptcha' $null))    { Set-Prop $cfg 'regCaptcha' $true }
    if ($null -eq (Get-PropSafe $cfg 'regSmsCode' $null))    { Set-Prop $cfg 'regSmsCode' $false }
    if ($null -eq (Get-PropSafe $cfg 'pwdComplexity' $null)) { Set-Prop $cfg 'pwdComplexity' 0 }
    if ([string]::IsNullOrWhiteSpace(('' + (Get-PropSafe $cfg 'domain' '')))) { Set-Prop $cfg 'domain' $DefaultDomain }
    if ([string]::IsNullOrWhiteSpace(('' + (Get-PropSafe $cfg 'teacherUser' '')))) { Set-Prop $cfg 'teacherUser' $DefaultTeacherUser }
    if ([string]::IsNullOrWhiteSpace(('' + (Get-PropSafe $cfg 'teacherSalt' ''))) -or
        [string]::IsNullOrWhiteSpace(('' + (Get-PropSafe $cfg 'teacherHash' '')))) {
        Set-Prop $cfg 'teacherSalt' ([Guid]::NewGuid().ToString('N').Substring(0, 16))
        Set-Prop $cfg 'teacherHash' (Get-PwdHash $DefaultTeacherPwd (Get-PropSafe $cfg 'teacherSalt' ''))
        Set-Prop $cfg 'needTeacherInit' $true
    }
    if ($null -eq (Get-PropSafe $cfg 'secQuestion' $null))   { Set-Prop $cfg 'secQuestion' '' }
    if ($null -eq (Get-PropSafe $cfg 'secAnswerSalt' $null)) { Set-Prop $cfg 'secAnswerSalt' '' }
    if ($null -eq (Get-PropSafe $cfg 'secAnswerHash' $null)) { Set-Prop $cfg 'secAnswerHash' '' }
    return $cfg
}

# ----------------------- 对象构造 -------------------------------
function New-User([string]$name, [string]$plainPwd, [string]$nick, [string]$phone = '', [string]$group = '') {
    $salt = [Guid]::NewGuid().ToString('N').Substring(0, 16)
    return [pscustomobject]@{
        username      = $name
        salt          = $salt
        passwordHash  = (Get-PwdHash $plainPwd $salt)
        nickname      = $nick
        phone         = $phone
        group         = $group
        createTime    = (Get-Now)
        lastLoginTime = ''
        lastLoginIp   = ''
        customBoxes   = @()
        blacklist     = @()
        scheduledMails= @()
        secQuestion   = ''
        secAnswerSalt = ''
        secAnswerHash = ''
        mails         = [pscustomobject]@{
            inbox = @()
            sent  = @()
            draft = @()
            junk  = @()
            trash = @()
        }
    }
}

function New-MailObj([string]$from, [string]$fromName, [string]$to, [string]$cc, [string]$subject, [string]$content, $atts, [bool]$read) {
    $a = @()
    $attList = AsArray $atts
    foreach ($x in $attList) {
        $a += [pscustomobject]@{ name = ('' + $x.name); size = $x.size; data = ('' + $x.data) }
    }
    return [pscustomobject]@{
        id          = [Guid]::NewGuid().ToString('N')
        from        = $from
        fromName    = $fromName
        to          = $to
        cc          = $cc
        subject     = $subject
        content     = $content
        attachments = $a
        time        = (Get-Now)
        read        = $read
        star        = $false
    }
}

function Find-User([string]$name) {
    $userList = AsArray $Script:Db.users
    foreach ($u in $userList) {
        if ($null -eq $u -or $u -is [System.Array] -or $u -is [string]) { continue }
        if (('' + $u.username) -eq $name) { return $u }
    }
    return $null
}

# ----------------------- 自定义分类箱 -------------------------------
function Get-CustomBoxKeys($u) {
    $keys = @()
    foreach ($cb in (AsArray (Get-PropSafe $u 'customBoxes' @()))) {
        $cid = ''
        try { $cid = ('' + $cb.id).Trim() } catch {}
        if ($cid -ne '') { $keys += ('cb_' + $cid) }
    }
    return ,$keys
}

function Find-CustomBox($u, [string]$id) {
    foreach ($cb in (AsArray (Get-PropSafe $u 'customBoxes' @()))) {
        if (('' + $cb.id) -eq $id) { return $cb }
    }
    return $null
}
function Get-BoxDisplayName($u, [string]$boxKey) {
    $sysNames = @{ inbox = '收件箱'; sent = '已发送'; draft = '草稿箱'; junk = '垃圾邮件'; trash = '已删除' }
    if ($sysNames.Contains($boxKey)) { return $sysNames[$boxKey] }
    if ($boxKey -like 'cb_*') {
        $cb = Find-CustomBox $u $boxKey.Substring(3)
        if ($null -ne $cb) { return ('' + (Get-PropSafe $cb 'name' $boxKey)) }
    }
    return $boxKey
}

function Test-CustomBoxName([string]$n) {
    $t = $n.Trim()
    if ($t -eq '') { return @{ ok = $false; msg = '分类箱名称不能为空' } }
    if ($t.Length -gt 12) { return @{ ok = $false; msg = '分类箱名称最多 12 个字符' } }
    if ($t -match "[,;`"`'\r\n<>]") { return @{ ok = $false; msg = '名称不能包含逗号、分号、引号、尖括号等字符' } }
    if (@('收件箱','已发送','草稿箱','垃圾邮件','已删除','星标邮件','星标','收件','草稿') -contains $t) { return @{ ok = $false; msg = '名称与系统文件夹重复，请换一个' } }
    return @{ ok = $true; name = $t }
}

# 校验箱键（内置或 cb_*）有效性；cb 加密且未解锁时返回 locked
function Test-BoxUnlocked($s, $u, [string]$boxKey) {
    if ($BoxNames -contains $boxKey) { return @{ ok = $true } }
    if ($boxKey -like 'cb_*') {
        $bid = $boxKey.Substring(3)
        $cb = Find-CustomBox $u $bid
        if ($null -eq $cb) { return @{ ok = $false; msg = '分类箱不存在或已被删除' } }
        $hasPwd = (('' + (Get-PropSafe $cb 'hash' '')) -ne '')
        if ($hasPwd) {
            $un = $false
            if ($null -ne $s -and $null -ne $s.unlocked -and $s.unlocked.Contains($bid)) { $un = $true }
            if (-not $un) { return @{ ok = $false; locked = $true; msg = '该分类箱已加密，请先输入密码解锁' } }
        }
        return @{ ok = $true; id = $bid; box = $cb }
    }
    return @{ ok = $false; msg = '文件夹无效' }
}

function Get-CustomBoxInfoList($s, $u) {
    $list = @()
    foreach ($cb in (AsArray (Get-PropSafe $u 'customBoxes' @()))) {
        $bid = ''
        try { $bid = ('' + $cb.id).Trim() } catch {}
        if ($bid -eq '') { continue }
        $key = 'cb_' + $bid
        $lst = AsArray (Get-PropSafe $u.mails $key @())
        $hasPwd = (('' + (Get-PropSafe $cb 'hash' '')) -ne '')
        $unlocked = $true
        if ($hasPwd) {
            $unlocked = ($null -ne $s -and $null -ne $s.unlocked -and $s.unlocked.Contains($bid))
        }
        $list += @{ id = $bid; name = ('' + (Get-PropSafe $cb 'name' '分类箱')); hasPwd = $hasPwd; unlocked = $unlocked; count = $lst.Count }
    }
    return ,$list
}

function Get-Counts($u) {
    $c = @{}
    foreach ($bx in $BoxNames) {
        $lst = AsArray (Get-PropSafe $u.mails $bx @())
        $c[$bx] = $lst.Count
    }
    foreach ($cb in (AsArray (Get-PropSafe $u 'customBoxes' @()))) {
        $cid = ''
        try { $cid = ('' + $cb.id).Trim() } catch {}
        if ($cid -eq '') { continue }
        $lst = AsArray (Get-PropSafe $u.mails ('cb_' + $cid) @())
        $c[('cb_' + $cid)] = $lst.Count
    }
    return $c
}

function Get-StarCount($u) {
    $n = 0
    $keys = @('inbox','sent','draft','junk') + @(Get-CustomBoxKeys $u)
    foreach ($bx in $keys) {
        $lst = AsArray (Get-PropSafe $u.mails $bx @())
        foreach ($m in $lst) {
            if ([bool](Get-PropSafe $m 'star' $false)) { $n++ }
        }
    }
    return $n
}

function Get-MailOut($m, [string]$srcBox) {
    return @{
        id          = ('' + $m.id)
        from        = (Get-DisplayAddr ('' + (Get-PropSafe $m 'from' '')))
        fromName    = ('' + (Get-PropSafe $m 'fromName' ''))
        to          = (Get-DisplayAddr ('' + (Get-PropSafe $m 'to' '')))
        cc          = (Get-DisplayAddr ('' + (Get-PropSafe $m 'cc' '')))
        subject     = ('' + (Get-PropSafe $m 'subject' ''))
        content     = ('' + (Get-PropSafe $m 'content' ''))
        attachments = (Get-PropSafe $m 'attachments' @())
        time        = ('' + (Get-PropSafe $m 'time' ''))
        read        = [bool](Get-PropSafe $m 'read' $false)
        star        = [bool](Get-PropSafe $m 'star' $false)
        origin      = ('' + (Get-PropSafe $m 'origin' ''))
        _box        = $srcBox
    }
}

function Clear-TeacherSessions {
    foreach ($k in @($Script:Sessions.Keys)) {
        if ($Script:Sessions[$k].role -eq 'teacher') { $Script:Sessions.Remove($k) | Out-Null }
    }
}

function Select-TargetUsers($b) {
    $grp = ('' + (Get-PropSafe $b 'group' '')).Trim()
    $targets = New-Object 'System.Collections.Generic.HashSet[string]'
    if ($grp -ne '') {
        $userList = AsArray $Script:Db.users
        foreach ($u in $userList) {
            if (('' + (Get-PropSafe $u 'group' '')) -eq $grp) { [void]$targets.Add(('' + $u.username)) }
        }
    } else {
        $bu = Get-PropSafe $b 'users' $null
        if ($null -ne $bu) {
            $arr = AsArray $bu
            foreach ($x in $arr) { [void]$targets.Add((('' + $x).Trim().ToLower())) }
        }
    }
    return ,$targets
}

# ----------------------- 数据自检与修复 ---------------------------
function Test-UsersDamaged {
    $raw = $Script:Db.users
    if ($null -eq $raw) { return $false }
    if (-not ($raw -is [System.Array])) { return $true }
    foreach ($it in @($raw)) {
        if ($it -is [System.Array]) { return $true }
    }
    return $false
}

function Clean-AttList($attRaw) {
    $attClean = @()
    foreach ($a in (Flatten-Deep $attRaw 4)) {
        if ($null -eq $a -or $a -is [System.Array] -or $a -is [string]) { continue }
        $an = ''; $ad = ''; $asz = 0
        try { $an = '' + $a.name } catch {}
        try { $ad = '' + $a.data } catch {}
        try { if ($null -ne $a.size) { $asz = [int]$a.size } } catch { $asz = 0 }
        if ($an -eq '' -or $ad -eq '') { continue }
        $attClean += @{ name = $an; size = $asz; data = $ad }
    }
    return ,$attClean
}

function Normalize-Database {
    $flatUsers = Flatten-Deep $Script:Db.users 6
    Set-Prop $Script:Db 'users' $flatUsers
    $gFlat = Flatten-Deep (Get-PropSafe $Script:Db 'groups' @()) 4
    $gClean = @()
    foreach ($g in $gFlat) {
        $gs = ('' + $g).Trim()
        if ($gs -ne '' -and -not ($gClean -contains $gs)) { $gClean += $gs }
    }
    Set-Prop $Script:Db 'groups' $gClean
    $rawList = AsArray $Script:Db.users
    $clean = @()
    foreach ($u in $rawList) {
        if ($null -eq $u -or $u -is [System.Array] -or $u -is [string] -or $u -is [ValueType]) {
            $Script:RepairInfo.dropped++
            continue
        }
        $name = ''
        try { $name = ('' + $u.username).Trim().ToLower() } catch { $name = '' }
        if ([string]::IsNullOrWhiteSpace($name)) { $Script:RepairInfo.dropped++; continue }
        Ensure-Prop $u 'username'      $name
        Ensure-Prop $u 'salt'          ([Guid]::NewGuid().ToString('N').Substring(0, 16))
        Ensure-Prop $u 'passwordHash'  ''
        Ensure-Prop $u 'nickname'      $name
        Ensure-Prop $u 'phone'         ''
        Ensure-Prop $u 'group'         ''
        Ensure-Prop $u 'createTime'    (Get-Now)
        Ensure-Prop $u 'lastLoginTime' ''
        Ensure-Prop $u 'lastLoginIp'   ''
        Ensure-Prop $u 'customBoxes'   @()
        Ensure-Prop $u 'blacklist'     @()
        Ensure-Prop $u 'scheduledMails' @()
        Ensure-Prop $u 'secQuestion'   ''
        Ensure-Prop $u 'secAnswerSalt' ''
        Ensure-Prop $u 'secAnswerHash' ''

        # 自定义分类箱：规整元数据，并注册对应 mails 动态箱体
        $boxKeys = @($BoxNames)
        $cbsClean = @()
        foreach ($cb in (Flatten-Deep (Get-PropSafe $u 'customBoxes' @()) 3)) {
            if ($null -eq $cb -or $cb -is [System.Array] -or $cb -is [string]) { continue }
            $cid = ''
            try { $cid = ('' + $cb.id).Trim() } catch {}
            if ([string]::IsNullOrWhiteSpace($cid)) {
                Set-Prop $cb 'id' ([Guid]::NewGuid().ToString('N'))
                $cid = '' + $cb.id
            }
            Ensure-Prop $cb 'name'    '分类箱'
            Ensure-Prop $cb 'salt'    ''
            Ensure-Prop $cb 'hash'    ''
            Ensure-Prop $cb 'created' (Get-Now)
            $key = 'cb_' + $cid
            if ($boxKeys -notcontains $key) { $boxKeys += $key }
            $cbsClean += $cb
        }
        Set-Prop $u 'customBoxes' $cbsClean

        # 黑名单：小写、去重、排除自己
        $blClean = @()
        foreach ($x in (Flatten-Deep (Get-PropSafe $u 'blacklist' @()) 3)) {
            $t = (('' + $x).Trim().ToLower())
            if ($t -ne '' -and $t -ne $name -and -not ($blClean -contains $t)) { $blClean += $t }
        }
        Set-Prop $u 'blacklist' $blClean

        # 定时任务：规整字段与附件
        $scClean = @()
        foreach ($t in (Flatten-Deep (Get-PropSafe $u 'scheduledMails' @()) 3)) {
            if ($null -eq $t -or $t -is [System.Array] -or $t -is [string]) { continue }
            $tid = ''
            try { $tid = ('' + $t.id) } catch {}
            if ([string]::IsNullOrWhiteSpace($tid)) { Set-Prop $t 'id' ([Guid]::NewGuid().ToString('N')) }
            Ensure-Prop $t 'to'       ''
            Ensure-Prop $t 'cc'       ''
            Ensure-Prop $t 'subject'  '(无主题)'
            Ensure-Prop $t 'content'  ''
            Ensure-Prop $t 'sendTime' (Get-Now)
            Ensure-Prop $t 'created'  (Get-Now)
            Set-Prop $t 'attachments' (Clean-AttList (Get-PropSafe $t 'attachments' @()))
            $scClean += $t
        }
        Set-Prop $u 'scheduledMails' $scClean

        $mp = $u.PSObject.Properties['mails']
        if ($null -eq $mp -or $null -eq $mp.Value) {
            $m = New-Object PSObject
            foreach ($bx in $BoxNames) { Add-Member -InputObject $m -MemberType NoteProperty -Name $bx -Value @() }
            Add-Member -InputObject $u -MemberType NoteProperty -Name 'mails' -Value $m -Force
            $Script:RepairInfo.fixedBoxes += $BoxNames.Count
        }
        foreach ($bx in $boxKeys) {
            $bp = $u.mails.PSObject.Properties[$bx]
            $rawBox = $null
            if ($null -eq $bp) { $Script:RepairInfo.fixedBoxes++ } else { $rawBox = $bp.Value }
            $items = Flatten-Deep $rawBox 6
            $fixed = @()
            foreach ($mm in $items) {
                if ($null -eq $mm -or $mm -is [System.Array] -or $mm -is [string]) { continue }
                $mid = ''
                try { $mid = '' + $mm.id } catch {}
                if ([string]::IsNullOrWhiteSpace($mid)) { Set-Prop $mm 'id' ([Guid]::NewGuid().ToString('N')) }
                Ensure-Prop $mm 'from'     ''
                Ensure-Prop $mm 'fromName' ''
                Ensure-Prop $mm 'to'       ''
                Ensure-Prop $mm 'cc'       ''
                Ensure-Prop $mm 'subject'  '(无主题)'
                Ensure-Prop $mm 'content'  ''
                Ensure-Prop $mm 'time'     (Get-Now)
                Ensure-Prop $mm 'read'     $false
                Ensure-Prop $mm 'star'     $false
                Ensure-Prop $mm 'origin'   ''
                Set-Prop $mm 'attachments' (Clean-AttList (Get-PropSafe $mm 'attachments' @()))
                $fixed += $mm
            }
            Set-Prop $u.mails $bx $fixed
        }
        $clean += $u
    }
    Set-Prop $Script:Db 'users' $clean
}

# ----------------------- 数据存取（AES-256 加密 + 自动备份） -----
function Save-Database {
    try {
        if ((Test-Path $DataFile) -and (((Get-Date) - $Script:LastBackup).TotalMinutes -ge 10)) {
            $bdir = Join-Path $Root 'backup'
            if (-not (Test-Path $bdir)) { New-Item -ItemType Directory -Path $bdir -Force | Out-Null }
            Copy-Item -Force $DataFile (Join-Path $bdir ('maildata-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.bak'))
            $olds = @(Get-ChildItem $bdir -Filter 'maildata-*.bak' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
            if ($olds.Count -gt 10) { ($olds | Select-Object -Skip 10) | ForEach-Object { Remove-Item -Force $_.FullName } }
            $Script:LastBackup = Get-Date
        }
    } catch {}
    $json = ConvertTo-Json -InputObject $Script:Db -Depth 20
    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.Key = $Script:AesKey
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.GenerateIV()
    $enc = $aes.CreateEncryptor()
    try {
        $plain  = [System.Text.Encoding]::UTF8.GetBytes($json)
        $cipher = $enc.TransformFinalBlock($plain, 0, $plain.Length)
        $payload = @{
            app    = 'easymail'
            ver    = 6
            time   = Get-Now
            iv     = [Convert]::ToBase64String($aes.IV)
            cipher = [Convert]::ToBase64String($cipher)
        } | ConvertTo-Json -Compress
        [System.IO.File]::WriteAllText($DataFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
    } finally { $enc.Dispose(); $aes.Dispose() }
}

function Load-Database {
    if (Test-Path $DataFile) {
        $Script:Db = $null
        try {
            $payload = [System.IO.File]::ReadAllText($DataFile) | ConvertFrom-Json
            $iv  = [Convert]::FromBase64String('' + $payload.iv)
            $cip = [Convert]::FromBase64String('' + $payload.cipher)
            $aes = [System.Security.Cryptography.Aes]::Create()
            $aes.Key = $Script:AesKey
            $aes.IV  = $iv
            $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
            $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
            $dec = $aes.CreateDecryptor()
            try {
                $plain = $dec.TransformFinalBlock($cip, 0, $cip.Length)
                $json  = [System.Text.Encoding]::UTF8.GetString($plain)
                $Script:Db = $json | ConvertFrom-Json
            } finally { $dec.Dispose(); $aes.Dispose() }
        } catch {
            $bak = $DataFile + '.bad'
            try { Move-Item -Force $DataFile $bak; Write-Log ('数据文件损坏，已备份为 ' + (Split-Path $bak -Leaf)) 'Red' } catch {}
        }
        if ($null -ne $Script:Db) {
            $damaged = Test-UsersDamaged
            $Script:RepairInfo = @{ nested = $damaged; filled = 0; dropped = 0; fixedBoxes = 0 }
            Normalize-Database
            $cfg = Get-ServerSettings
            if ([bool](Get-PropSafe $cfg 'needTeacherInit' $false)) {
                Set-Prop $cfg 'needTeacherInit' $false
                Write-Log ('教师账号已初始化为默认 ' + (Get-PropSafe $cfg 'teacherUser' 'admin') + ' / ' + $DefaultTeacherPwd + '，请尽快登录后台修改密码') 'Yellow'
            }
            if ($damaged -or $Script:RepairInfo.filled -gt 0 -or $Script:RepairInfo.dropped -gt 0 -or $Script:RepairInfo.fixedBoxes -gt 0) {
                try { Copy-Item -Force $DataFile ($DataFile + '.pre-repair') } catch {}
                Save-Database
                Write-Log ('数据结构自检：发现异常并已自动修复（users结构异常: ' + $damaged + '，补全字段 ' + $Script:RepairInfo.filled + ' 处，规整箱体 ' + $Script:RepairInfo.fixedBoxes + ' 个，清理残损 ' + $Script:RepairInfo.dropped + ' 条）') 'Yellow'
            }
            $Script:CurDomain = ('' + (Get-PropSafe $cfg 'domain' $DefaultDomain))
            $gLoaded = AsArray (Get-PropSafe $Script:Db 'groups' @())
            Write-Log ('已加载班级 ' + $gLoaded.Count + ' 个' + $(if ($gLoaded.Count -gt 0) { '：' + ($gLoaded -join '、') } else { '' })) 'DarkCyan'
            $userList = AsArray $Script:Db.users
            Write-Log ('已加载数据文件 maildata.json（有效邮箱账号 ' + $userList.Count + ' 个）') 'DarkCyan'
            return
        }
    }
    $Script:Db = New-Object PSObject -Property @{ users = @() }
    Get-ServerSettings | Out-Null
    Save-Database
    $Script:CurDomain = $DefaultDomain
    Write-Log '已创建新的加密数据库 maildata.json' 'DarkCyan'
}

# ----------------------- 会话管理 -------------------------------
function New-Session([string]$user, [string]$role) {
    $token = [Guid]::NewGuid().ToString('N')
    $Script:Sessions[$token] = @{ user = $user; role = $role; time = (Get-Date); unlocked = (New-Object 'System.Collections.Generic.HashSet[string]') }
    $now = Get-Date
    $expired = @()
    foreach ($k in @($Script:Sessions.Keys)) {
        if ((($now) - $Script:Sessions[$k].time).TotalHours -gt 240) { $expired += $k }
    }
    foreach ($k in $expired) { $Script:Sessions.Remove($k) | Out-Null }
    $ck = @()
    foreach ($k in @($Script:Captchas.Keys)) { if (($now - $Script:Captchas[$k].time).TotalMinutes -gt 10) { $ck += $k } }
    foreach ($k in $ck) { $Script:Captchas.Remove($k) | Out-Null }
    $sk = @()
    foreach ($k in @($Script:SmsCodes.Keys)) { if (($now - $Script:SmsCodes[$k].time).TotalMinutes -gt 10) { $sk += $k } }
    foreach ($k in $sk) { $Script:SmsCodes.Remove($k) | Out-Null }
    return $token
}

function Get-Session([string]$token, [string]$role) {
    if ([string]::IsNullOrWhiteSpace($token)) { return $null }
    $s = $Script:Sessions[$token]
    if ($null -eq $s) { return $null }
    if ($s.role -ne $role) { return $null }
    if (((Get-Date) - $s.time).TotalHours -gt 240) { $Script:Sessions.Remove($token) | Out-Null; return $null }
    $s.time = Get-Date
    return $s
}

# ----------------------- HTTP 工具 ------------------------------
function Get-Body($req) {
    try {
        $reader = New-Object System.IO.StreamReader($req.InputStream, [System.Text.Encoding]::UTF8)
        $raw = $reader.ReadToEnd()
        $reader.Dispose()
        if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
        return ($raw | ConvertFrom-Json)
    } catch { return $null }
}

function Send-Json($res, $obj, [int]$code = 200) {
    $json = ConvertTo-Json -InputObject $obj -Depth 20 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $res.StatusCode = $code
    $res.ContentType = 'application/json; charset=utf-8'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
    $res.OutputStream.Close()
}

function Send-File($res, [string]$path) {
    if (-not (Test-Path $path)) {
        Send-Json $res @{ success = $false; msg = ('缺少页面文件: ' + [System.IO.Path]::GetFileName($path)) } 404
        return
    }
    $html = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($html)
    $res.StatusCode = 200
    try { $res.Headers.Add('Cache-Control', 'no-cache'); $res.Headers.Add('Expires', '-1') } catch {}
    $res.ContentType = 'text/html; charset=utf-8'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
    $res.OutputStream.Close()
}

# ----------------------- 收件人 / 附件校验 ----------------------
function Split-Recipients([string]$raw) {
    if ([string]::IsNullOrWhiteSpace($raw)) { return ,@() }
    $p = @($raw -split '[,;，；、\s]+' | ForEach-Object { ($_ -replace '@.*$', '').Trim().ToLower() } | Where-Object { $_ -ne '' } | Select-Object -Unique)
    return ,$p
}

function Test-Attachments($atts) {
    $list = @()
    $arr = AsArray $atts
    if ($arr.Count -eq 0) { return @{ ok = $true; list = $list } }
    if ($arr.Count -gt $MaxAttachCount) { return @{ ok = $false; msg = ('附件数量最多 ' + $MaxAttachCount + ' 个') } }
    $total = 0
    foreach ($a in $arr) {
        $name = ('' + $a.name)
        $data = ('' + $a.data)
        if ($name -eq '' -or $data -eq '') { continue }
        $name = [System.IO.Path]::GetFileName($name)
        if ($name.Length -gt 80) { $name = $name.Substring(0, 80) }
        $ext = [System.IO.Path]::GetExtension($name).ToLower()
        if ($BlockedExt -contains $ext) { return @{ ok = $false; msg = ('出于安全考虑，不允许发送该类型附件: ' + $name) } }
        if ($data -notmatch '^[A-Za-z0-9+/]+={0,2}$') { return @{ ok = $false; msg = ('附件 ' + $name + ' 数据无效') } }
        $pad = 0; if ($data.EndsWith('==')) { $pad = 2 } elseif ($data.EndsWith('=')) { $pad = 1 }
        $size = [Math]::Floor($data.Length * 3 / 4) - $pad
        if ($size -gt $MaxAttachEach) { return @{ ok = $false; msg = ('附件 ' + $name + ' 超过 1MB 大小限制') } }
        $total += $size
        if ($total -gt $MaxAttachTotal) { return @{ ok = $false; msg = '附件总大小不能超过 3MB' } }
        $list += @{ name = $name; size = $size; data = $data }
    }
    return @{ ok = $true; list = $list }
}

# ----------------------- 业务校验 -------------------------------
function Test-Username([string]$name) {
    if ($name -eq '') { return @{ ok = $false; msg = '请输入邮箱账号' } }
    if ($name.Length -lt 6) { return @{ ok = $false; msg = '邮箱账号需 6-18 个字符，请继续输入' } }
    if ($name.Length -gt 18) { return @{ ok = $false; msg = '邮箱账号最多 18 个字符' } }
    if ($name -notmatch '^[a-z][a-z0-9_]*$') { return @{ ok = $false; msg = '只能使用字母、数字、下划线，且需以字母开头' } }
    if ($null -ne (Find-User $name)) { return @{ ok = $false; msg = '抱歉，该邮箱地址已被注册' } }
    return @{ ok = $true; msg = '恭喜，该邮箱地址可以注册' }
}

function Test-GroupName([string]$g) {
    $gs = $g.Trim()
    if ($gs -eq '') { return @{ ok = $false; msg = '班级名称不能为空' } }
    if ($gs.Length -gt 20) { return @{ ok = $false; msg = '班级名称最多 20 个字符' } }
    if ($gs -match "[,;`"`'\r\n]") { return @{ ok = $false; msg = '班级名称不能包含逗号、分号、引号等字符' } }
    return @{ ok = $true; msg = ''; name = $gs }
}

# ================================================================
#            导入 / 导出 工具
# ================================================================

function Xml-Escape([string]$s) {
    return (('' + $s) -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;' -replace "'", '&apos;')
}

function Test-NumberCell([string]$s) {
    return ($s -ne '' -and $s -match '^-?\d{1,10}(\.\d+)?$')
}

function ConvertTo-ColLetters([int]$n) {
    $s = ''
    while ($n -gt 0) {
        $m = ($n - 1) % 26
        $s = [string][char](65 + $m) + $s
        $n = [int](($n - 1 - $m) / 26)
    }
    return $s
}

function ConvertFrom-ColRef([string]$ref) {
    $letters = ''
    foreach ($ch in (('' + $ref).ToUpper().ToCharArray())) {
        if ($ch -ge 'A' -and $ch -le 'Z') { $letters += $ch }
    }
    if ($letters -eq '') { return 0 }
    $n = 0
    foreach ($ch in $letters.ToCharArray()) { $n = $n * 26 + ([int][char]$ch - 64) }
    return $n
}

function Decode-TextBytes([byte[]]$bytes) {
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    $strict = New-Object System.Text.UTF8Encoding($false, $true)
    try { return $strict.GetString($bytes) } catch {}
    try { return [System.Text.Encoding]::GetEncoding(936).GetString($bytes) } catch {}
    return [System.Text.Encoding]::Default.GetString($bytes)
}

function Parse-CsvText([string]$text) {
    $text = ('' + $text) -replace "`r`n", "`n"
    $text = $text -replace "`r", "`n"
    $rows = @()
    $cur = New-Object System.Collections.Generic.List[string]
    $field = New-Object System.Text.StringBuilder
    $inQ = $false
    $chars = $text.ToCharArray()
    for ($i = 0; $i -lt $chars.Length; $i++) {
        $ch = $chars[$i]
        if ($inQ) {
            if ($ch -eq '"') {
                if ($i + 1 -lt $chars.Length -and $chars[$i + 1] -eq '"') { [void]$field.Append('"'); $i++ }
                else { $inQ = $false }
            } else { [void]$field.Append($ch) }
        } else {
            if ($ch -eq '"') { $inQ = $true }
            elseif ($ch -eq ',') { $cur.Add($field.ToString()); [void]$field.Clear() }
            elseif ($ch -eq "`n") { $cur.Add($field.ToString()); [void]$field.Clear(); $rows += ,@($cur.ToArray()); $cur.Clear() }
            else { [void]$field.Append($ch) }
        }
    }
    if ($field.Length -gt 0 -or $cur.Count -gt 0) { $cur.Add($field.ToString()); [void]$field.Clear(); $rows += ,@($cur.ToArray()) }
    return ,$rows
}

function Parse-HtmlTable([string]$text) {
    $rows = @()
    $trs = [regex]::Matches(('' + $text), '<tr[^>]*>(.*?)</tr>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($tr in $trs) {
        $tds = [regex]::Matches($tr.Groups[1].Value, '<t[dh][^>]*>(.*?)</t[dh]>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($tds.Count -eq 0) { continue }
        $line = @()
        foreach ($c in $tds) {
            $v = $c.Groups[1].Value
            $v = $v -replace '<br\s*/?>', ' '
            $v = $v -replace '<[^>]+>', ''
            $v = $v -replace '&nbsp;', ' ' -replace '&amp;', '&' -replace '&lt;', '<' -replace '&gt;', '>' -replace '&quot;', '"' -replace '&#39;', "'"
            $line += $v.Trim()
        }
        $rows += ,@($line)
    }
    return ,$rows
}

function Parse-Xmlss([string]$text) {
    $doc = New-Object System.Xml.XmlDocument
    $doc.LoadXml(('' + $text))
    $nsm = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
    $nsm.AddNamespace('ss', 'urn:schemas-microsoft-com:office:spreadsheet')
    $wsNode = $doc.SelectSingleNode('//ss:Worksheet', $nsm)
    if ($null -eq $wsNode) { throw '不是有效的 Excel XML 文件' }
    $rows = @()
    foreach ($row in $wsNode.SelectNodes('.//ss:Row', $nsm)) {
        $line = New-Object System.Collections.Generic.List[string]
        foreach ($cell in $row.SelectNodes('ss:Cell', $nsm)) {
            $idxAttr = $cell.GetAttribute('Index', 'urn:schemas-microsoft-com:office:spreadsheet')
            $v = ''
            $dn = $cell.SelectSingleNode('ss:Data', $nsm)
            if ($null -ne $dn) { $v = $dn.InnerText }
            if ($idxAttr -ne '') {
                $idx = 0
                if ([int]::TryParse($idxAttr, [ref]$idx) -and $idx -ge 1) {
                    while ($line.Count -lt ($idx - 1)) { $line.Add('') }
                    $line.Add($v)
                    continue
                }
            }
            $line.Add($v)
        }
        $rows += ,@($line.ToArray())
    }
    return ,$rows
}

function Parse-XlsxFile([byte[]]$bytes) {
    $ms = New-Object System.IO.MemoryStream(,$bytes)
    $zip = $null
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($ms, [System.IO.Compression.ZipArchiveMode]::Read)
        $entries = @{}
        foreach ($e in $zip.Entries) { $entries[$e.FullName.ToLower()] = $e }
        $readEntry = {
            param($name)
            $e = $entries[('' + $name).ToLower()]
            if ($null -eq $e) { return $null }
            $st = $e.Open()
            $sr = New-Object System.IO.StreamReader($st, [System.Text.Encoding]::UTF8)
            $t = $sr.ReadToEnd()
            $sr.Dispose(); $st.Dispose()
            return $t
        }
        $wbXml = & $readEntry 'xl/workbook.xml'
        if ([string]::IsNullOrWhiteSpace($wbXml)) { throw '不是有效的 xlsx 文件（缺少工作簿定义）' }
        $doc = New-Object System.Xml.XmlDocument
        $doc.LoadXml($wbXml)
        $sheetAttr = ''
        foreach ($sh in $doc.GetElementsByTagName('sheet')) {
            foreach ($a in $sh.Attributes) {
                if ($a.LocalName -eq 'id') { $sheetAttr = $a.Value; break }
            }
            if ($sheetAttr -ne '') { break }
        }
        if ($sheetAttr -eq '') { throw '不是有效的 xlsx 文件（未找到工作表）' }
        $relsXml = & $readEntry 'xl/_rels/workbook.xml.rels'
        $target = ''
        if (-not [string]::IsNullOrWhiteSpace($relsXml)) {
            $rd = New-Object System.Xml.XmlDocument
            $rd.LoadXml($relsXml)
            foreach ($rel in $rd.GetElementsByTagName('Relationship')) {
                if (('' + $rel.GetAttribute('Id')) -eq $sheetAttr) { $target = ('' + $rel.GetAttribute('Target')); break }
            }
        }
        if ($target -eq '') { throw '不是有效的 xlsx 文件（未找到工作表数据）' }
        $target = $target.TrimStart('/').ToLower()
        if (-not $target.StartsWith('xl/')) { $target = 'xl/' + $target }
        $sheetXml = & $readEntry $target
        if ([string]::IsNullOrWhiteSpace($sheetXml)) { throw '不是有效的 xlsx 文件（工作表内容为空）' }
        $shared = @()
        $ssXml = & $readEntry 'xl/sharedStrings.xml'
        if (-not [string]::IsNullOrWhiteSpace($ssXml)) {
            $sd = New-Object System.Xml.XmlDocument
            $sd.LoadXml($ssXml)
            foreach ($si in $sd.GetElementsByTagName('si')) {
                $txt = ''
                foreach ($tn in $si.GetElementsByTagName('t')) { $txt += $tn.InnerText }
                $shared += $txt
            }
        }
        $sdoc = New-Object System.Xml.XmlDocument
        $sdoc.LoadXml($sheetXml)
        $rows = @()
        foreach ($row in $sdoc.GetElementsByTagName('row')) {
            $line = New-Object System.Collections.Generic.List[string]
            $prevCol = 0
            foreach ($c in $row.GetElementsByTagName('c')) {
                $ref = '' + $c.GetAttribute('r')
                $col = 0
                if ($ref -ne '') { $col = ConvertFrom-ColRef $ref } else { $col = $prevCol + 1 }
                while ($line.Count -lt ($col - 1)) { $line.Add('') }
                $t = '' + $c.GetAttribute('t')
                $v = ''
                if ($t -eq 'inlineStr') {
                    $isNode = $c.GetElementsByTagName('is')
                    if ($isNode.Count -gt 0) {
                        foreach ($tn in $isNode[0].GetElementsByTagName('t')) { $v += $tn.InnerText }
                    }
                } else {
                    $vNodes = $c.GetElementsByTagName('v')
                    if ($vNodes.Count -gt 0) { $v = $vNodes[0].InnerText }
                    if ($t -eq 's' -and $v -ne '') {
                        $idx = 0
                        if ([int]::TryParse($v, [ref]$idx) -and $idx -ge 0 -and $idx -lt $shared.Count) { $v = '' + $shared[$idx] } else { $v = '' }
                    }
                }
                $line.Add($v)
                $prevCol = $col
            }
            $rows += ,@($line.ToArray())
        }
        return ,$rows
    } finally {
        if ($null -ne $zip) { $zip.Dispose() }
        $ms.Dispose()
    }
}

function Parse-OleXlsFile([byte[]]$bytes) {
    $tmp = Join-Path $env:TEMP ('emimport_' + [Guid]::NewGuid().ToString('N') + '.xls')
    [System.IO.File]::WriteAllBytes($tmp, $bytes)
    $job = $null
    try {
        $job = Start-Job -ScriptBlock {
            param($path)
            $app = $null
            foreach ($progid in @('Excel.Application', 'Ket.Application', 'et.Application')) {
                try { $app = New-Object -ComObject $progid; break } catch { $app = $null }
            }
            if ($null -eq $app) { throw '本机未检测到 Excel 或 WPS，无法读取旧版 .xls；请用 Excel/WPS 打开该文件后另存为 .xlsx 或 .csv，再重新导入' }
            $app.Visible = $false
            $app.DisplayAlerts = $false
            $wb = $app.Workbooks.Open($path, 0, $true)
            try {
                $ws = $wb.Worksheets.Item(1)
                $vals = $ws.UsedRange.Value2
                $rows = @()
                if ($vals -is [System.Array]) {
                    $rc = $vals.GetLength(0); $cc = $vals.GetLength(1)
                    for ($r = 1; $r -le $rc; $r++) {
                        $line = @()
                        for ($c = 1; $c -le $cc; $c++) { $line += ('' + $vals.GetValue($r, $c)) }
                        $rows += ,$line
                    }
                } else {
                    $rows = ,@(('' + $vals))
                }
                return ,$rows
            } finally {
                try { $wb.Close($false) } catch {}
                try { $app.Quit() } catch {}
                try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) | Out-Null } catch {}
            }
        } -ArgumentList $tmp
        $done = Wait-Job $job -Timeout 25
        if ($null -eq $done) { throw '读取 .xls 超时；请用 Excel/WPS 将文件另存为 .xlsx 或 .csv 后重新导入' }
        if ($job.State -eq 'Failed') {
            $msg = ''
            $errs = @(Receive-Job $job -ErrorAction SilentlyContinue 2>&1)
            foreach ($e in $errs) {
                if ($e -is [System.Management.Automation.ErrorRecord]) { $msg = $e.Exception.Message; break }
            }
            if ($msg -eq '') { $msg = '读取 .xls 失败；请将文件另存为 .xlsx 或 .csv 后重试' }
            throw $msg
        }
        $out = @(Receive-Job $job)
        $rows = @()
        foreach ($r in $out) {
            if ($r -is [System.Array]) {
                $line = @()
                foreach ($x in $r) { $line += ('' + $x) }
                $rows += ,@($line)
            } else {
                $rows += ,@(('' + $r))
            }
        }
        return ,$rows
    } finally {
        if ($null -ne $job) { try { Remove-Job $job -Force -ErrorAction SilentlyContinue } catch {} }
        try { Remove-Item -Force $tmp -ErrorAction SilentlyContinue } catch {}
    }
}

function Parse-ImportFile([string]$filename, [byte[]]$bytes) {
    $isZip = $bytes.Length -ge 4 -and $bytes[0] -eq 0x50 -and $bytes[1] -eq 0x4B -and ($bytes[2] -eq 0x03 -or $bytes[2] -eq 0x05 -or $bytes[2] -eq 0x07) -and ($bytes[3] -eq 0x04 -or $bytes[3] -eq 0x06 -or $bytes[3] -eq 0x08)
    $isOle = $bytes.Length -ge 4 -and $bytes[0] -eq 0xD0 -and $bytes[1] -eq 0xCF -and $bytes[2] -eq 0x11 -and $bytes[3] -eq 0xE0
    if ($isZip) { return @{ rows = (Parse-XlsxFile $bytes); kind = 'xlsx' } }
    if ($isOle) { return @{ rows = (Parse-OleXlsFile $bytes); kind = 'xls(二进制)' } }
    $text = Decode-TextBytes $bytes
    if ($text -match '<Workbook' -or $text -match 'schemas-microsoft-com:office:spreadsheet') {
        return @{ rows = (Parse-Xmlss $text); kind = 'xls(XML)' }
    }
    if ($text -match '<html' -or $text -match '<table' -or $text -match '<!doctype') {
        return @{ rows = (Parse-HtmlTable $text); kind = 'xls(网页表格)' }
    }
    return @{ rows = (Parse-CsvText $text); kind = 'csv' }
}

function New-XlsxFile($rows, [string]$sheetName) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
    [void]$sb.Append('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')
    $rIdx = 0
    foreach ($row in $rows) {
        $rIdx++
        [void]$sb.Append(('<row r="' + $rIdx + '">'))
        $cIdx = 0
        foreach ($v in $row) {
            $cIdx++
            $sv = '' + $v
            if ($sv -eq '') { continue }
            $ref = (ConvertTo-ColLetters $cIdx) + $rIdx
            if (Test-NumberCell $sv) {
                [void]$sb.Append(('<c r="' + $ref + '"><v>' + (Xml-Escape $sv) + '</v></c>'))
            } else {
                [void]$sb.Append(('<c r="' + $ref + '" t="inlineStr"><is><t xml:space="preserve">' + (Xml-Escape $sv) + '</t></is></c>'))
            }
        }
        [void]$sb.Append('</row>')
    }
    [void]$sb.Append('</sheetData></worksheet>')
    $sheetXml  = $sb.ToString()
    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'
    $rootRels  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    $workbook  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' + (Xml-Escape $sheetName) + '" sheetId="1" r:id="rId1"/></sheets></workbook>'
    $wbRels    = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
    $styles    = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>'
    $u8 = New-Object System.Text.UTF8Encoding($false)
    $ms = New-Object System.IO.MemoryStream
    $zip = New-Object System.IO.Compression.ZipArchive($ms, [System.IO.Compression.ZipArchiveMode]::Create, $true)
    try {
        $parts = @(
            @('[Content_Types].xml', $contentTypes),
            @('_rels/.rels', $rootRels),
            @('xl/workbook.xml', $workbook),
            @('xl/_rels/workbook.xml.rels', $wbRels),
            @('xl/styles.xml', $styles),
            @('xl/worksheets/sheet1.xml', $sheetXml)
        )
        foreach ($p in $parts) {
            $entry = $zip.CreateEntry([string]$p[0])
            $w = New-Object System.IO.StreamWriter($entry.Open(), $u8)
            $w.Write([string]$p[1])
            $w.Dispose()
        }
    } finally { $zip.Dispose() }
    $bytes = $ms.ToArray()
    $ms.Dispose()
    return ,$bytes
}

function New-XlsFile($rows, [string]$sheetName) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<?xml version="1.0" encoding="UTF-8"?>' + "`r`n")
    [void]$sb.Append('<?mso-application progid="Excel.Sheet"?>' + "`r`n")
    [void]$sb.Append('<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' + "`r`n")
    [void]$sb.Append(('<Worksheet ss:Name="' + (Xml-Escape $sheetName) + '">' + "`r`n"))
    [void]$sb.Append('<Table>' + "`r`n")
    foreach ($row in $rows) {
        [void]$sb.Append('<Row>' + "`r`n")
        foreach ($v in $row) {
            $sv = '' + $v
            if (Test-NumberCell $sv) {
                [void]$sb.Append('<Cell><Data ss:Type="Number">' + (Xml-Escape $sv) + '</Data></Cell>')
            } else {
                [void]$sb.Append('<Cell><Data ss:Type="String">' + (Xml-Escape $sv) + '</Data></Cell>')
            }
        }
        [void]$sb.Append('</Row>' + "`r`n")
    }
    [void]$sb.Append('</Table>' + "`r`n</Worksheet>" + "`r`n</Workbook>")
    return ,([System.Text.Encoding]::UTF8.GetBytes($sb.ToString()))
}

function New-CsvFile($rows) {
    $lines = @()
    foreach ($row in $rows) {
        $cells = @()
        foreach ($v in $row) {
            $sv = '' + $v
            if ($sv -match '[",\r\n]') { $cells += ('"' + ($sv -replace '"', '""') + '"') } else { $cells += $sv }
        }
        $lines += ($cells -join ',')
    }
    $text = ($lines -join "`r`n") + "`r`n"
    return ,((New-Object System.Text.UTF8Encoding($true)).GetBytes($text))
}

function Get-UserStatList {
    $users = AsArray $Script:Db.users
    $today = (Get-Date).ToString('yyyy-MM-dd')
    $now = Get-Date
    $totalMails = 0; $todayReg = 0; $todayLogin = 0
    $onlineUsers = @{}
    foreach ($k in @($Script:Sessions.Keys)) {
        $ss = $Script:Sessions[$k]
        if ($ss.role -eq 'student' -and (($now - $ss.time).TotalMinutes -le 15)) { $onlineUsers[$ss.user] = $true }
    }
    $statList = @()
    foreach ($u in $users) {
        $ib = AsArray (Get-PropSafe $u.mails 'inbox' @())
        $st = AsArray (Get-PropSafe $u.mails 'sent'  @())
        $dr = AsArray (Get-PropSafe $u.mails 'draft' @())
        $jk = AsArray (Get-PropSafe $u.mails 'junk'  @())
        $tr = AsArray (Get-PropSafe $u.mails 'trash' @())
        $cbTotal = 0
        foreach ($cb in (AsArray (Get-PropSafe $u 'customBoxes' @()))) {
            $cid = ''
            try { $cid = ('' + $cb.id).Trim() } catch {}
            if ($cid -eq '') { continue }
            $cbTotal += (AsArray (Get-PropSafe $u.mails ('cb_' + $cid) @())).Count
        }
        $totalMails += $ib.Count + $st.Count + $dr.Count + $jk.Count + $tr.Count + $cbTotal
        if (('' + (Get-PropSafe $u 'createTime' '')).StartsWith($today)) { $todayReg++ }
        if (('' + (Get-PropSafe $u 'lastLoginTime' '')).StartsWith($today)) { $todayLogin++ }
        $unread = @($ib | Where-Object { -not $_.read }).Count
        $statList += @{
            username      = ('' + $u.username)
            nickname      = ('' + (Get-PropSafe $u 'nickname' ''))
            group         = ('' + (Get-PropSafe $u 'group' ''))
            phone         = ('' + (Get-PropSafe $u 'phone' ''))
            createTime    = ('' + (Get-PropSafe $u 'createTime' ''))
            lastLoginTime = ('' + (Get-PropSafe $u 'lastLoginTime' ''))
            lastLoginIp   = ('' + (Get-PropSafe $u 'lastLoginIp' ''))
            inbox         = $ib.Count
            unread        = $unread
            sent          = $st.Count
            draft         = $dr.Count
            junk          = $jk.Count
            trash         = $tr.Count
        }
    }
    return @{
        list       = @($statList | Sort-Object -Property { $_.createTime })
        totalUsers = $users.Count
        totalMails = $totalMails
        todayReg   = $todayReg
        todayLogin = $todayLogin
        online     = $onlineUsers.Count
    }
}

# ----------------------- 统一投递（普通发送 / 定时发送共用） ---------
function Split-Deliverable([string]$fromUser, [string[]]$names) {
    $ok = @(); $rejected = @()
    foreach ($n in $names) {
        $tu = Find-User $n
        if ($null -eq $tu) { continue }
        $bl = AsArray (Get-PropSafe $tu 'blacklist' @())
        if ($bl -contains $fromUser) { $rejected += $n } else { $ok += $n }
    }
    return @{ ok = $ok; rejected = $rejected }
}

function Invoke-DeliverMail($u, [string]$toRaw, [string]$ccRaw, [string]$subject, [string]$content, $atts) {
    $toNames = Split-Recipients $toRaw
    $ccNames = Split-Recipients $ccRaw
    if ($toNames.Count -eq 0) { return @{ ok = $false; msg = '请输入收件人账号' } }
    if (($toNames.Count + $ccNames.Count) -gt 20) { return @{ ok = $false; msg = '一次最多发送给 20 位收件人' } }
    foreach ($n in @($toNames + $ccNames)) {
        if ($null -eq (Find-User $n)) { return @{ ok = $false; msg = ('收件人 ' + $n + '@' + $Script:CurDomain + ' 不存在，请核对账号') } }
    }
    $targets = @()
    foreach ($n in @($toNames + $ccNames)) { $targets += (Find-User $n) }
    $uniq = @($targets | ForEach-Object { $_.username } | Select-Object -Unique)
    $del = Split-Deliverable ('' + $u.username) $uniq
    if (@($del.ok).Count -eq 0) {
        return @{ ok = $false; msg = ('发送失败：以下收件人已将你加入黑名单，拒收你的邮件 —— ' + (@($del.rejected) -join '、')) }
    }
    $toStr = (@($toNames | ForEach-Object { $_ + '@' + $Script:CurDomain }) -join '; ')
    $ccStr = ''
    if ($ccNames.Count -gt 0) { $ccStr = (@($ccNames | ForEach-Object { $_ + '@' + $Script:CurDomain }) -join '; ') }
    foreach ($n in @($del.ok)) {
        $tu = Find-User $n
        $inboxList = AsArray (Get-PropSafe $tu.mails 'inbox' @())
        $tu.mails.inbox = @($inboxList) + (New-MailObj (('' + $u.username) + '@' + $Script:CurDomain) ('' + (Get-PropSafe $u 'nickname' $u.username)) $toStr $ccStr $subject $content $atts $false)
    }
    $sentList = AsArray (Get-PropSafe $u.mails 'sent' @())
    $u.mails.sent = @($sentList) + (New-MailObj (('' + $u.username) + '@' + $Script:CurDomain) ('' + (Get-PropSafe $u 'nickname' $u.username)) $toStr $ccStr $subject $content $atts $true)
    return @{ ok = $true; delivered = @($del.ok); rejected = @($del.rejected) }
}

# ----------------------- 定时发送调度 -------------------------------
function Invoke-ScheduledMails {
    $now = Get-Date
    $anyChanged = $false
    $userList = AsArray $Script:Db.users
    foreach ($u in $userList) {
        if ($null -eq $u) { continue }
        $sched = AsArray (Get-PropSafe $u 'scheduledMails' @())
        if ($sched.Count -eq 0) { continue }
        $keep = @()
        $userChanged = $false
        foreach ($t in $sched) {
            $sd = [datetime]::MinValue
            try { [datetime]::TryParse(('' + (Get-PropSafe $t 'sendTime' '')), [ref]$sd) | Out-Null } catch {}
            if ($sd -gt $now) { $keep += $t; continue }
            $subject = ('' + (Get-PropSafe $t 'subject' '(无主题)'))
            $r2 = Invoke-DeliverMail $u ('' + (Get-PropSafe $t 'to' '')) ('' + (Get-PropSafe $t 'cc' '')) $subject ('' + (Get-PropSafe $t 'content' '')) (Get-PropSafe $t 'attachments' @())
            if ([bool]($r2.ok)) {
                $rj = @($r2.rejected)
                $rjNote = ''
                if ($rj.Count -gt 0) { $rjNote = '（拒收: ' + ($rj -join ',') + '）' }
                Write-Log ('定时邮件已发送: ' + $u.username + ' -> ' + (@($r2.delivered) -join ',') + ' 「' + $subject + '」' + $rjNote) 'Yellow'
            } else {
                Write-Log ('定时邮件发送失败(任务已取消): ' + $u.username + ' 「' + $subject + '」原因: ' + ('' + $r2.msg)) 'Red'
            }
            $userChanged = $true
        }
        if ($userChanged) { Set-Prop $u 'scheduledMails' $keep; $anyChanged = $true }
    }
    if ($anyChanged) { Save-Database }
}

# ----------------------- API 调度 -------------------------------
function Handle-Api([string]$op, $b, $res, [string]$addr) {
    switch ($op) {

        'info' {
            Send-Json $res @{ success = $true; domain = $Script:CurDomain }
        }

        'regconfig' {
            $cfg = Get-ServerSettings
            Send-Json $res @{
                success       = $true
                domain        = $Script:CurDomain
                regCaptcha    = [bool](Get-PropSafe $cfg 'regCaptcha' $true)
                regSmsCode    = [bool](Get-PropSafe $cfg 'regSmsCode' $false)
                pwdComplexity = [int](Get-PropSafe $cfg 'pwdComplexity' 0)
            }
        }

        'captcha' {
            $c = New-CaptchaObject
            $cid = [Guid]::NewGuid().ToString('N')
            $Script:Captchas[$cid] = @{ code = $c.code; time = (Get-Date) }
            Send-Json $res @{ success = $true; id = $cid; svg = $c.svg }
        }

        'sendsms' {
            $cfg = Get-ServerSettings
            if (-not [bool](Get-PropSafe $cfg 'regSmsCode' $false)) { Send-Json $res @{ success = $false; msg = '当前未开启短信验证' }; return }
            $phone = ('' + $b.phone).Trim()
            if ($phone -notmatch '^1\d{10}$') { Send-Json $res @{ success = $false; msg = '请输入正确的 11 位手机号（1 开头）' }; return }
            $ent = $null
            if ($Script:SmsCodes.ContainsKey($phone)) { $ent = $Script:SmsCodes[$phone] }
            if ($null -ne $ent -and ((Get-Date) - $ent.sendTime).TotalSeconds -lt 60) {
                Send-Json $res @{ success = $false; msg = '发送太频繁，请 60 秒后再试' }; return
            }
            $code = ''
            for ($i = 0; $i -lt 6; $i++) { $code += (Get-Random -Minimum 0 -Maximum 10) }
            $Script:SmsCodes[$phone] = @{ code = $code; time = (Get-Date); sendTime = (Get-Date) }
            Write-Log ('虚拟短信: 已向 ' + $phone + ' 发送验证码 ' + $code + '（教学模拟）') 'DarkYellow'
            Send-Json $res @{ success = $true; msg = '验证码已发送'; code = $code }
        }

        'checkname' {
            $name = ('' + $b.username).Trim().ToLower()
            $chk = Test-Username $name
            Send-Json $res @{ success = $true; available = $chk.ok; msg = $chk.msg }
        }

        'register' {
            $name = ('' + $b.username).Trim().ToLower()
            $chk = Test-Username $name
            if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
            $pwd  = '' + $b.password
            $pwd2 = '' + $b.password2
            if ($pwd.Length -lt 6 -or $pwd.Length -gt 16) { Send-Json $res @{ success = $false; msg = '密码长度需为 6-16 个字符' }; return }
            if ($pwd -match '\s') { Send-Json $res @{ success = $false; msg = '密码中不能包含空格' }; return }
            if ($pwd -ne $pwd2) { Send-Json $res @{ success = $false; msg = '两次输入的密码不一致' }; return }
            $cfg = Get-ServerSettings
            $useCaptcha = [bool](Get-PropSafe $cfg 'regCaptcha' $true)
            $useSms     = [bool](Get-PropSafe $cfg 'regSmsCode' $false)
            $pwdLevel   = [int](Get-PropSafe $cfg 'pwdComplexity' 0)
            if ($pwdLevel -ge 1 -and ($pwd -notmatch '[a-zA-Z]' -or $pwd -notmatch '[0-9]')) {
                Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须同时包含字母和数字' }; return
            }
            if ($pwdLevel -ge 2 -and $pwd -notmatch '[^a-zA-Z0-9]') {
                Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须包含字母、数字和特殊字符' }; return
            }
            if ($useCaptcha) {
                $cid = ('' + $b.captchaId).Trim()
                $cv  = ('' + $b.captcha).Trim().ToUpper()
                if ($cid -eq '' -or $cv -eq '') { Send-Json $res @{ success = $false; msg = '请输入图形验证码' }; return }
                $ent = $null
                if ($Script:Captchas.ContainsKey($cid)) { $ent = $Script:Captchas[$cid] }
                $Script:Captchas.Remove($cid) | Out-Null
                if ($null -eq $ent -or ((Get-Date) - $ent.time).TotalMinutes -gt 10) {
                    Send-Json $res @{ success = $false; msg = '图形验证码已过期，请点击图片刷新后重新输入' }; return
                }
                if ($ent.code -ne $cv) { Send-Json $res @{ success = $false; msg = '图形验证码不正确，请看清楚后重试' }; return }
            }
            $phone = ''
            if ($useSms) {
                $phone = ('' + $b.phone).Trim()
                if ($phone -notmatch '^1\d{10}$') { Send-Json $res @{ success = $false; msg = '请输入正确的 11 位手机号（1 开头）' }; return }
                $sc = ('' + $b.smscode).Trim()
                $ent = $null
                if ($Script:SmsCodes.ContainsKey($phone)) { $ent = $Script:SmsCodes[$phone] }
                if ($null -eq $ent -or ((Get-Date) - $ent.time).TotalMinutes -gt 5) {
                    Send-Json $res @{ success = $false; msg = '短信验证码已过期，请重新获取' }; return
                }
                if ($ent.code -ne $sc) { Send-Json $res @{ success = $false; msg = '短信验证码不正确，请核对后重试' }; return }
                $Script:SmsCodes.Remove($phone) | Out-Null
            }
            $nick = ('' + $b.nickname).Trim()
            if ($nick -eq '') { $nick = $name }
            if ($nick.Length -gt 12) { Send-Json $res @{ success = $false; msg = '昵称最多 12 个字符' }; return }
            $u = New-User $name $pwd $nick $phone
            $userList = AsArray $Script:Db.users
            $Script:Db.users = @($userList) + $u
            Save-Database
            Write-Log ('注册新邮箱: ' + $name + '@' + $Script:CurDomain + '（昵称: ' + $nick + '）') 'Green'
            Send-Json $res @{ success = $true; msg = '注册成功'; username = $name; nickname = $nick }
        }

        'login' {
            $name = ('' + $b.username).Trim().ToLower()
            $pwd  = '' + $b.password
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '该邮箱地址尚未注册，请先注册' }; return }
            $salt = Get-PropSafe $u 'salt' ''
            $hash = Get-PropSafe $u 'passwordHash' ''
            if ((Get-PwdHash $pwd $salt) -ne $hash) { Send-Json $res @{ success = $false; msg = '账号或密码错误，请重新输入' }; return }
            Set-Prop $u 'lastLoginTime' (Get-Now)
            Set-Prop $u 'lastLoginIp'   $addr
            Save-Database
            $token = New-Session $name 'student'
            Write-Log ('学生登录: ' + $name + '@' + $Script:CurDomain + '（IP: ' + $addr + '）') 'Cyan'
            Send-Json $res @{ success = $true; token = $token; username = ('' + $u.username); nickname = ('' + (Get-PropSafe $u 'nickname' $name)); domain = $Script:CurDomain }
        }

        'auth' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            Send-Json $res @{ success = $true; username = ('' + $u.username); nickname = ('' + (Get-PropSafe $u 'nickname' $s.user)); domain = $Script:CurDomain }
        }

        'logout' {
            $Script:Sessions.Remove(('' + $b.token)) | Out-Null
            Send-Json $res @{ success = $true; msg = '已退出登录' }
        }

        'changepwd' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $old = '' + $b.oldpwd
            $new = '' + $b.newpwd
            $salt = Get-PropSafe $u 'salt' ''
            $hash = Get-PropSafe $u 'passwordHash' ''
            if ((Get-PwdHash $old $salt) -ne $hash) { Send-Json $res @{ success = $false; msg = '原密码不正确' }; return }
            if ($new.Length -lt 6 -or $new.Length -gt 16) { Send-Json $res @{ success = $false; msg = '新密码长度需为 6-16 个字符' }; return }
            if ($new -match '\s') { Send-Json $res @{ success = $false; msg = '新密码中不能包含空格' }; return }
            if ($new -eq $old) { Send-Json $res @{ success = $false; msg = '新密码不能与原密码相同' }; return }
            $cfg = Get-ServerSettings
            $pwdLevel = [int](Get-PropSafe $cfg 'pwdComplexity' 0)
            if ($pwdLevel -ge 1 -and ($new -notmatch '[a-zA-Z]' -or $new -notmatch '[0-9]')) { Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须同时包含字母和数字' }; return }
            if ($pwdLevel -ge 2 -and $new -notmatch '[^a-zA-Z0-9]') { Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须包含字母、数字和特殊字符' }; return }
            Set-Prop $u 'salt'         ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $u 'passwordHash' (Get-PwdHash $new (Get-PropSafe $u 'salt' ''))
            Save-Database
            Write-Log ('学生修改密码: ' + $u.username) 'Cyan'
            Send-Json $res @{ success = $true; msg = '密码修改成功，请牢记新密码！' }
        }
    # ---------- 学生修改昵称 ----------
    'changenick' {
        $s = Get-Session ('' + $b.token) 'student'
        if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
        $u = Find-User $s.user
        if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
        $nick = ('' + $b.nickname).Trim()
        if ($nick -eq '') { $nick = $s.user }              # 与注册逻辑一致：留空恢复为账号名
        if ($nick.Length -gt 12) { Send-Json $res @{ success = $false; msg = '昵称最多 12 个字符' }; return }
        if ($nick -match "[,;`"`'\r\n<>]") { Send-Json $res @{ success = $false; msg = '昵称不能包含逗号、分号、引号、尖括号等字符' }; return }
        Set-Prop $u 'nickname' $nick
        Save-Database
        Write-Log ('学生修改昵称: ' + $u.username + ' → ' + $nick) 'Cyan'
        Send-Json $res @{ success = $true; msg = '昵称修改成功'; nickname = $nick }
    }

        # ---------- 密保问题：设置 / 查询 ----------
        'get_security_question' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            Send-Json $res @{ success = $true; secQuestion = ('' + (Get-PropSafe $u 'secQuestion' '')) }
        }

        'set_security_question' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $qid = ('' + $b.qid).Trim()
            $ans = ('' + $b.answer).Trim()
            if ($qid -eq '') {
                # 清除
                Set-Prop $u 'secQuestion'   ''
                Set-Prop $u 'secAnswerSalt' ''
                Set-Prop $u 'secAnswerHash' ''
                Save-Database
                Write-Log ('学生清除密保: ' + $u.username) 'DarkGray'
                Send-Json $res @{ success = $true; msg = '已清除密保问题' }
                return
            }
            if ($ans.Length -lt 2 -or $ans.Length -gt 30) {
                Send-Json $res @{ success = $false; msg = '密保答案需为 2-30 个字符' }; return
            }
            $salt = [Guid]::NewGuid().ToString('N').Substring(0, 16)
            Set-Prop $u 'secQuestion'   $qid
            Set-Prop $u 'secAnswerSalt' $salt
            Set-Prop $u 'secAnswerHash' (Get-AnswerHash $ans $salt)
            Save-Database
            Write-Log ('学生设置密保: ' + $u.username + ' (题号 ' + $qid + ')') 'Cyan'
            Send-Json $res @{ success = $true; msg = '密保问题设置成功' }
        }

        # ---------- 忘记密码：查账号 / 取信息 / 验证 / 重置 ----------
        'forgot_check' {
            $name = ('' + $b.username).Trim().ToLower()
            if ($name -eq '') { Send-Json $res @{ success = $false; msg = '请输入邮箱账号' }; return }
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '该邮箱账号不存在' }; return }
            Send-Json $res @{ success = $true; msg = '账号存在' }
        }

        'forgot_info' {
            $name = ('' + $b.username).Trim().ToLower()
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            $qid = ('' + (Get-PropSafe $u 'secQuestion' '')).Trim()
            $hasAns = (('' + (Get-PropSafe $u 'secAnswerHash' '')) -ne '')
            $phone = ('' + (Get-PropSafe $u 'phone' '')).Trim()
            $phoneMask = ''
            if ($phone -match '^1\d{10}$') {
                $phoneMask = $phone.Substring(0,3) + '****' + $phone.Substring(7)
            }
            Send-Json $res @{
                success     = $true
                secQuestion = $(if ($hasAns) { $qid } else { '' })
                phone       = $phoneMask
                hasPhone    = ($phone -match '^1\d{10}$')
                hasSecQ     = ($hasAns -and $qid -ne '')
            }
        }

        'forgot_sendsms' {
            $name = ('' + $b.username).Trim().ToLower()
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            $phone = ('' + (Get-PropSafe $u 'phone' '')).Trim()
            if ($phone -notmatch '^1\d{10}$') { Send-Json $res @{ success = $false; msg = '该账号未绑定手机号，请改用密保问题找回' }; return }
            $key = 'forgot:' + $phone
            if ($Script:SmsCodes.ContainsKey($key)) {
                $ent0 = $Script:SmsCodes[$key]
                if ($null -ne $ent0 -and ((Get-Date) - $ent0.sendTime).TotalSeconds -lt 60) {
                    Send-Json $res @{ success = $false; msg = '发送太频繁，请 60 秒后再试' }; return
                }
            }
            $code = ''
            for ($i = 0; $i -lt 6; $i++) { $code += (Get-Random -Minimum 0 -Maximum 10) }
            $Script:SmsCodes[$key] = @{ code = $code; time = (Get-Date); sendTime = (Get-Date); user = $name }
            Write-Log ('忘记密码短信: ' + $name + ' 验证码 ' + $code + '（教学模拟）') 'DarkYellow'
            Send-Json $res @{ success = $true; msg = '验证码已发送'; code = $code }
        }

        'forgot_verify_sec' {
            $name = ('' + $b.username).Trim().ToLower()
            $ans  = ('' + $b.answer).Trim()
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            $hash = ('' + (Get-PropSafe $u 'secAnswerHash' ''))
            if ($hash -eq '') { Send-Json $res @{ success = $false; msg = '该账号未设置密保问题' }; return }
            if ($ans -eq '') { Send-Json $res @{ success = $false; msg = '请输入密保答案' }; return }
            $salt = ('' + (Get-PropSafe $u 'secAnswerSalt' ''))
            if ((Get-AnswerHash $ans $salt) -ne $hash) {
                $Script:ForgotLock.count++
                if ($Script:ForgotLock.count -ge $ForgotMaxFail) {
                    $Script:ForgotLock.until = (Get-Date).AddMinutes($ForgotLockMin)
                    $Script:ForgotLock.count = 0
                    Write-Log ('忘记密码验证失败次数过多，锁定 ' + $ForgotLockMin + ' 分钟（' + $name + '）') 'Red'
                    Send-Json $res @{ success = $false; msg = ('密保答案错误次数过多，请 ' + $ForgotLockMin + ' 分钟后再试') }; return
                }
                Send-Json $res @{ success = $false; msg = ('密保答案不正确（还可尝试 ' + ($ForgotMaxFail - $Script:ForgotLock.count) + ' 次）') }; return
            }
            Send-Json $res @{ success = $true; msg = '密保验证通过' }
        }

        'forgot_verify_sms' {
            $name = ('' + $b.username).Trim().ToLower()
            $code = ('' + $b.code).Trim()
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            $phone = ('' + (Get-PropSafe $u 'phone' '')).Trim()
            if ($phone -notmatch '^1\d{10}$') { Send-Json $res @{ success = $false; msg = '该账号未绑定手机号' }; return }
            $key = 'forgot:' + $phone
            if (-not $Script:SmsCodes.ContainsKey($key)) { Send-Json $res @{ success = $false; msg = '请先获取短信验证码' }; return }
            $ent = $Script:SmsCodes[$key]
            if ($null -eq $ent -or ((Get-Date) - $ent.time).TotalMinutes -gt 5) {
                Send-Json $res @{ success = $false; msg = '验证码已过期，请重新获取' }; return
            }
            if (('' + $ent.code) -ne $code) { Send-Json $res @{ success = $false; msg = '验证码不正确' }; return }
            $Script:SmsCodes.Remove($key) | Out-Null
            Send-Json $res @{ success = $true; msg = '验证码验证通过' }
        }

        'forgot_reset' {
            $name = ('' + $b.username).Trim().ToLower()
            $new  = '' + $b.newpwd
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            if ($new.Length -lt 6 -or $new.Length -gt 16) { Send-Json $res @{ success = $false; msg = '新密码长度需为 6-16 个字符' }; return }
            if ($new -match '\s') { Send-Json $res @{ success = $false; msg = '新密码中不能包含空格' }; return }
            $cfg = Get-ServerSettings
            $pwdLevel = [int](Get-PropSafe $cfg 'pwdComplexity' 0)
            if ($pwdLevel -ge 1 -and ($new -notmatch '[a-zA-Z]' -or $new -notmatch '[0-9]')) {
                Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须同时包含字母和数字' }; return
            }
            if ($pwdLevel -ge 2 -and $new -notmatch '[^a-zA-Z0-9]') {
                Send-Json $res @{ success = $false; msg = '密码复杂度不足：必须包含字母、数字和特殊字符' }; return
            }
            Set-Prop $u 'salt'         ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $u 'passwordHash' (Get-PwdHash $new (Get-PropSafe $u 'salt' ''))
            Save-Database
            Write-Log ('忘记密码重置成功: ' + $u.username) 'Green'
            Send-Json $res @{ success = $true; msg = '密码已重置，请用新密码登录' }
        }

        'contacts' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $now = Get-Date
            $me = Find-User $s.user
            $myBl = @()
            if ($null -ne $me) { $myBl = AsArray (Get-PropSafe $me 'blacklist' @()) }
            $list = @()
            $userList = AsArray $Script:Db.users
            foreach ($x in $userList) {
                if ($null -eq $x -or ('' + $x.username) -eq $s.user) { continue }
                $online = $false
                foreach ($k in @($Script:Sessions.Keys)) {
                    $ss = $Script:Sessions[$k]
                    if ($ss.role -eq 'student' -and $ss.user -eq ('' + $x.username) -and (($now - $ss.time).TotalMinutes -le 15)) { $online = $true; break }
                }
                $list += @{ username = ('' + $x.username); nickname = ('' + (Get-PropSafe $x 'nickname' '')); group = ('' + (Get-PropSafe $x 'group' '')); online = $online; blocked = ($myBl -contains ('' + $x.username)) }
            }
            $list = @($list | Sort-Object -Property { $_.username })
            Send-Json $res @{ success = $true; contacts = $list; total = $userList.Count }
        }

        # ---------- 邮件列表 ----------
        'mails' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread = @($inList | Where-Object { -not $_.read }).Count
            if ($box -eq 'starred') {
                $outList = @()
                $scanKeys = @('inbox','sent','draft','junk') + @(Get-CustomBoxKeys $u)
                foreach ($bx in $scanKeys) {
                    if ($bx -like 'cb_*') {
                        $v = Test-BoxUnlocked $s $u $bx
                        if (-not $v.ok) { continue }
                    }
                    $lst = AsArray (Get-PropSafe $u.mails $bx @())
                    foreach ($m in $lst) {
                        if ([bool](Get-PropSafe $m 'star' $false)) { $outList += (Get-MailOut $m $bx) }
                    }
                }
                $outList = @($outList | Sort-Object -Property { $_.time } -Descending)
                Send-Json $res @{ success = $true; box = 'starred'; mails = $outList; counts = (Get-Counts $u); unread = $unread; starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u); domain = $Script:CurDomain }
                return
            }
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            if ($box -like 'cb_*') {
                $v = Test-BoxUnlocked $s $u $box
                if (-not $v.ok) {
                    if ([bool]($v.locked)) {
                        Send-Json $res @{ success = $true; box = $box; locked = $true; mails = @(); counts = (Get-Counts $u); unread = $unread; starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u); domain = $Script:CurDomain }
                        return
                    }
                    Send-Json $res @{ success = $false; msg = $v.msg }; return
                }
            }
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $list    = @($boxList | Sort-Object -Property { $_.time } -Descending)
            $outList = @()
            foreach ($m in $list) { $outList += (Get-MailOut $m $box) }
            Send-Json $res @{ success = $true; box = $box; mails = $outList; counts = (Get-Counts $u); unread = $unread; starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u); domain = $Script:CurDomain }
        }

        'readmail' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $item = $inList | Where-Object { $_.id -eq ('' + $b.id) } | Select-Object -First 1
            if ($null -ne $item) { Set-Prop $item 'read' $true; Save-Database }
            $inList2 = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread  = @($inList2 | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; unread = $unread; counts = (Get-Counts $u) }
        }

        'readall' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            foreach ($m in $inList) { Set-Prop $m 'read' $true }
            Save-Database
            Write-Log ('学生全部标为已读: ' + $u.username) 'DarkGray'
            Send-Json $res @{ success = $true; msg = '全部邮件已标记为已读'; unread = 0; counts = (Get-Counts $u) }
        }

        # ---------- 星标 ----------
        'setstar' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v = Test-BoxUnlocked $s $u $box
            if (-not $v.ok) { Send-Json $res @{ success = $false; msg = $v.msg }; return }
            $id = '' + $b.id
            $want = [bool]($b.star -eq $true)
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $item = $boxList | Where-Object { $_.id -eq $id } | Select-Object -First 1
            if ($null -eq $item) { Send-Json $res @{ success = $false; msg = '邮件不存在或已被删除' }; return }
            Set-Prop $item 'star' $want
            Save-Database
            $msg = '已标为星标邮件'
            if (-not $want) { $msg = '已取消星标' }
            Send-Json $res @{ success = $true; msg = $msg; star = $want; starCount = (Get-StarCount $u) }
        }

        'batchstar' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v = Test-BoxUnlocked $s $u $box
            if (-not $v.ok) { Send-Json $res @{ success = $false; msg = $v.msg }; return }
            $want = [bool]($b.star -eq $true)
            $idSet = New-Object 'System.Collections.Generic.HashSet[string]'
            $idArr = AsArray $b.ids
            foreach ($x in $idArr) { [void]$idSet.Add((('' + $x).Trim())) }
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $n = 0
            foreach ($m in $boxList) {
                if ($idSet.Contains(('' + $m.id))) { Set-Prop $m 'star' $want; $n++ }
            }
            Save-Database
            $msg = ('已为 ' + $n + ' 封邮件添加星标')
            if (-not $want) { $msg = ('已取消 ' + $n + ' 封邮件的星标') }
            Send-Json $res @{ success = $true; msg = $msg; count = $n; starCount = (Get-StarCount $u) }
        }

        # ---------- 批量已读 ----------
        'batchread' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v = Test-BoxUnlocked $s $u $box
            if (-not $v.ok) { Send-Json $res @{ success = $false; msg = $v.msg }; return }
            $idSet = New-Object 'System.Collections.Generic.HashSet[string]'
            $idArr = AsArray $b.ids
            foreach ($x in $idArr) { [void]$idSet.Add((('' + $x).Trim())) }
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $n = 0
            foreach ($m in $boxList) {
                if ($idSet.Contains(('' + $m.id))) { Set-Prop $m 'read' $true; $n++ }
            }
            Save-Database
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = ('已将 ' + $n + ' 封邮件标为已读'); count = $n; unread = $unread; counts = (Get-Counts $u) }
        }

        # ---------- 移动 ----------
        'movemail' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v1 = Test-BoxUnlocked $s $u $box
            if (-not $v1.ok) { Send-Json $res @{ success = $false; msg = $v1.msg }; return }
            $toBox = ('' + $b.toBox).Trim().ToLower()
            $v2 = Test-BoxUnlocked $s $u $toBox
            if (-not $v2.ok) { Send-Json $res @{ success = $false; msg = $v2.msg }; return }
            if ($toBox -eq $box) { Send-Json $res @{ success = $false; msg = '邮件已在该文件夹中' }; return }
            $id = '' + $b.id
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $item = $boxList | Where-Object { $_.id -eq $id } | Select-Object -First 1
            if ($null -eq $item) { Send-Json $res @{ success = $false; msg = '邮件不存在或已被移动' }; return }
            Set-Prop $u.mails$box @($boxList | Where-Object { $_.id -ne $id })
            if ($toBox -eq 'trash' -or $toBox -eq 'junk') { Set-Prop $item 'origin' $box } else { Set-Prop $item 'origin' '' }
            $destList = AsArray (Get-PropSafe $u.mails $toBox @())
            Set-Prop $u.mails$toBox (@($destList) +$item)
            Save-Database
            $toName = Get-BoxDisplayName $u $toBox
            $msg = ('邮件已移动到【' + $toName + '】')
            if ($toBox -eq 'junk') { $msg = '已举报为垃圾邮件，移入【垃圾邮件】' }
            if ($toBox -eq 'trash') { $msg = '邮件已移入【已删除】' }
            if ($toBox -eq 'draft') { $msg = '已移动到【草稿箱】，可编辑后重新发送' }
            Write-Log ('邮件移动: ' + $u.username + ' ' + $box + ' -> ' + $toBox) 'DarkGray'
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = $msg; unread = $unread; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        'batchmove' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v1 = Test-BoxUnlocked $s $u $box
            if (-not $v1.ok) { Send-Json $res @{ success = $false; msg = $v1.msg }; return }
            $toBox = ('' + $b.toBox).Trim().ToLower()
            $v2 = Test-BoxUnlocked $s $u $toBox
            if (-not $v2.ok) { Send-Json $res @{ success = $false; msg = $v2.msg }; return }
            if ($toBox -eq $box) { Send-Json $res @{ success = $false; msg = '邮件已在该文件夹中' }; return }
            $idSet = New-Object 'System.Collections.Generic.HashSet[string]'
            $idArr = AsArray $b.ids
            foreach ($x in $idArr) { [void]$idSet.Add((('' + $x).Trim())) }
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $moveItems = @()
            foreach ($m in $boxList) {
                if ($idSet.Contains(('' + $m.id))) { $moveItems += $m }
            }
            if ($moveItems.Count -eq 0) { Send-Json $res @{ success = $false; msg = '未找到要移动的邮件' }; return }
            Set-Prop $u.mails$box @($boxList | Where-Object { -not $idSet.Contains(('' +$_.id)) })
            $destList = AsArray (Get-PropSafe $u.mails $toBox @())
            foreach ($item in $moveItems) {
                if ($toBox -eq 'trash' -or $toBox -eq 'junk') { Set-Prop $item 'origin' $box } else { Set-Prop $item 'origin' '' }
                $destList = @($destList) + $item
            }
            Set-Prop $u.mails$toBox @($destList)
            Save-Database
            $toName = Get-BoxDisplayName $u $toBox
            $n = $moveItems.Count
            $msg = ('已将 ' + $n + ' 封邮件移动到【' + $toName + '】')
            if ($toBox -eq 'junk') { $msg = ('已将 ' + $n + ' 封邮件举报为垃圾邮件') }
            if ($toBox -eq 'trash') { $msg = ('已将 ' + $n + ' 封邮件移入【已删除】') }
            if ($toBox -eq 'draft') { $msg = ('已将 ' + $n + ' 封邮件移动到【草稿箱】，可编辑后重新发送') }
            Write-Log ('邮件批量移动: ' + $u.username + ' ' + $box + ' -> ' + $toBox + '（' + $n + ' 封）') 'DarkGray'
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = $msg; count = $n; unread = $unread; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        # ---------- 删除 ----------
        'delmail' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v = Test-BoxUnlocked $s $u $box
            if (-not $v.ok) { Send-Json $res @{ success = $false; msg = $v.msg }; return }
            $id = '' + $b.id
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $item = $boxList | Where-Object { $_.id -eq $id } | Select-Object -First 1
            if ($null -eq $item) { Send-Json $res @{ success = $false; msg = '邮件不存在或已被删除' }; return }
            Set-Prop $u.mails$box @($boxList | Where-Object { $_.id -ne$id })
            if ($box -eq 'trash') {
                $msg = '邮件已彻底删除'
            } else {
                Set-Prop $item 'origin' $box
                $trashList = AsArray (Get-PropSafe $u.mails 'trash' @())
                $u.mails.trash = @($trashList) + $item
                $msg = '邮件已移入【已删除】'
            }
            Save-Database
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread  = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = $msg; unread = $unread; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        'batchdel' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $box = ('' + $b.box).Trim().ToLower()
            if ($BoxNames -notcontains $box -and $box -notlike 'cb_*') { $box = 'inbox' }
            $v = Test-BoxUnlocked $s $u $box
            if (-not $v.ok) { Send-Json $res @{ success = $false; msg = $v.msg }; return }
            $perm = [bool]($b.perm -eq $true)
            $idSet = New-Object 'System.Collections.Generic.HashSet[string]'
            $idArr = AsArray $b.ids
            foreach ($x in $idArr) { [void]$idSet.Add((('' + $x).Trim())) }
            if ($idSet.Count -eq 0) { Send-Json $res @{ success = $false; msg = '未选择任何邮件' }; return }
            $boxList = AsArray (Get-PropSafe $u.mails $box @())
            $n = 0
            if ($box -eq 'trash' -or $perm) {
                $kept = @()
                foreach ($m in $boxList) {
                    if ($idSet.Contains(('' + $m.id))) { $n++ } else { $kept += $m }
                }
                Set-Prop $u.mails$box @($kept)
                $msg = ('已彻底删除 ' + $n + ' 封邮件')
            } else {
                $kept = @(); $toTrash = @()
                foreach ($m in $boxList) {
                    if ($idSet.Contains(('' + $m.id))) { Set-Prop $m 'origin' $box; $toTrash += $m; $n++ } else { $kept += $m }
                }
                Set-Prop $u.mails$box @($kept)
                $trashList = AsArray (Get-PropSafe $u.mails 'trash' @())
                $u.mails.trash = @($trashList) + @($toTrash)
                $msg = ('已将 ' + $n + ' 封邮件移入【已删除】')
            }
            Save-Database
            Write-Log ('邮件批量删除: ' + $u.username + '（' + $n + ' 封）') 'DarkGray'
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = $msg; count = $n; unread = $unread; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        'restore' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $id = '' + $b.id
            $trashList = AsArray (Get-PropSafe $u.mails 'trash' @())
            $item = $trashList | Where-Object { $_.id -eq $id } | Select-Object -First 1
            if ($null -eq $item) { Send-Json $res @{ success = $false; msg = '邮件不存在或已被恢复' }; return }
            $origin = '' + (Get-PropSafe $item 'origin' '')
            if ($origin -like 'cb_*') {
                $v = Test-BoxUnlocked $s $u $origin
                if (-not $v.ok) { $origin = 'inbox' }
            } elseif ($BoxNames -notcontains $origin -or $origin -eq 'trash') {
                $origin = 'inbox'
            }
            $u.mails.trash = @($trashList | Where-Object { $_.id -ne $id })
            $originList = AsArray (Get-PropSafe $u.mails $origin @())
            Set-Prop $u.mails$origin (@($originList) +$item)
            Save-Database
            $originName = Get-BoxDisplayName $u $origin
            $inList = AsArray (Get-PropSafe $u.mails 'inbox' @())
            $unread  = @($inList | Where-Object { -not $_.read }).Count
            Send-Json $res @{ success = $true; msg = ('邮件已恢复到【' + $originName + '】'); unread = $unread; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        'emptytrash' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $u.mails.trash = @()
            Save-Database
            Write-Log ('学生清空回收站: ' + $u.username) 'DarkGray'
            Send-Json $res @{ success = $true; msg = '回收站已清空'; unread = 0; counts = (Get-Counts $u); starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        'emptyjunk' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $u.mails.junk = @()
            Save-Database
            Write-Log ('学生清空垃圾邮件: ' + $u.username) 'DarkGray'
            Send-Json $res @{ success = $true; msg = '垃圾邮件已清空'; counts = (Get-Counts $u); unread = @(AsArray (Get-PropSafe $u.mails 'inbox' @()) | Where-Object { -not $_.read }).Count; starCount = (Get-StarCount $u); customBoxes = (Get-CustomBoxInfoList $s $u) }
        }

        # ---------- 发送 ----------
        'send' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $subject = ('' + $b.subject).Trim()
            if ($subject -eq '') { $subject = '(无主题)' }
            $content = '' + $b.content
            if ($content.Trim() -eq '') { Send-Json $res @{ success = $false; msg = '邮件正文不能为空' }; return }
            $attChk = Test-Attachments $b.attachments
            if (-not $attChk.ok) { Send-Json $res @{ success = $false; msg = $attChk.msg }; return }
            $r2 = Invoke-DeliverMail $u ('' + $b.to) ('' + $b.cc) $subject $content $attChk.list
            if (-not [bool]($r2.ok)) { Send-Json $res @{ success = $false; msg = ('' + $r2.msg) }; return }
            $did = '' + $b.draftId
            if ($did -ne '') {
                $draftList = AsArray (Get-PropSafe $u.mails 'draft' @())
                $u.mails.draft = @($draftList | Where-Object { $_.id -ne $did })
            }
            Save-Database
            $delivered = @($r2.delivered)
            $rejected  = @($r2.rejected)
            $okMsg = ('邮件已成功发送给 ' + $delivered.Count + ' 位收件人')
            if (($delivered.Count -eq 1) -and (($delivered[0] + '') -eq ('' + $u.username))) {
                $okMsg = '邮件已发送给自己，请到【收件箱】查收'
            }
            if ($rejected.Count -gt 0) {
                $okMsg += ('；' + ($rejected -join '、') + ' 已将你加入黑名单，拒收了此邮件')
            }
            Write-Log ('邮件: ' + $u.username + ' -> ' + ($delivered -join ',') + ' 「' + $subject + '」（附件 ' + $attChk.list.Count + ' 个）' + $(if ($rejected.Count -gt 0) { '（拒收: ' + ($rejected -join ',') + '）' } else { '' })) 'Yellow'
            Send-Json $res @{ success = $true; msg = $okMsg }
        }

        'draft' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $toNames = Split-Recipients ('' + $b.to)
            $ccNames = Split-Recipients ('' + $b.cc)
            $subject = ('' + $b.subject).Trim()
            if ($subject -eq '') { $subject = '(无主题)' }
            $content = '' + $b.content
            $attChk = Test-Attachments $b.attachments
            if (-not $attChk.ok) { Send-Json $res @{ success = $false; msg = $attChk.msg }; return }
            $toStr = ''
            if ($toNames.Count -gt 0) { $toStr = (@($toNames | ForEach-Object { $_ + '@' + $Script:CurDomain }) -join '; ') }
            $ccStr = ''
            if ($ccNames.Count -gt 0) { $ccStr = (@($ccNames | ForEach-Object { $_ + '@' + $Script:CurDomain }) -join '; ') }
            $did = '' + $b.draftId
            $updated = $false
            $draftList = AsArray (Get-PropSafe $u.mails 'draft' @())
            foreach ($item in $draftList) {
                if ($item.id -eq $did) {
                    Set-Prop $item 'to'          $toStr
                    Set-Prop $item 'cc'          $ccStr
                    Set-Prop $item 'subject'     $subject
                    Set-Prop $item 'content'     $content
                    Set-Prop $item 'attachments' $attChk.list
                    Set-Prop $item 'time'        (Get-Now)
                    $updated = $true
                    break
                }
            }
            if (-not $updated) {
                $draftList2 = AsArray (Get-PropSafe $u.mails 'draft' @())
                $u.mails.draft = @($draftList2) + (New-MailObj (('' + $u.username) + '@' + $Script:CurDomain) ('' + (Get-PropSafe $u 'nickname' $u.username)) $toStr $ccStr $subject $content $attChk.list $true)
            }
            Save-Database
            Send-Json $res @{ success = $true; msg = '草稿已保存，可到【草稿箱】查看' }
        }

        # ---------- 定时发送 ----------
        'sendschedule' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $toNames = Split-Recipients ('' + $b.to)
            $ccNames = Split-Recipients ('' + $b.cc)
            if ($toNames.Count -eq 0) { Send-Json $res @{ success = $false; msg = '请输入收件人账号' }; return }
            if (($toNames.Count + $ccNames.Count) -gt 20) { Send-Json $res @{ success = $false; msg = '一次最多发送给 20 位收件人' }; return }
            foreach ($n in @($toNames + $ccNames)) {
                if ($null -eq (Find-User $n)) { Send-Json $res @{ success = $false; msg = ('收件人 ' + $n + '@' + $Script:CurDomain + ' 不存在，请核对账号') }; return }
            }
            $subject = ('' + $b.subject).Trim()
            if ($subject -eq '') { $subject = '(无主题)' }
            $content = '' + $b.content
            if ($content.Trim() -eq '') { Send-Json $res @{ success = $false; msg = '邮件正文不能为空' }; return }
            $attChk = Test-Attachments $b.attachments
            if (-not $attChk.ok) { Send-Json $res @{ success = $false; msg = $attChk.msg }; return }
            $sd = [datetime]::MinValue
            $okParse = $false
            try { $okParse = [datetime]::TryParse(('' + $b.sendTime), [ref]$sd) } catch { $okParse = $false }
            if (-not $okParse) { Send-Json $res @{ success = $false; msg = '定时时间格式不正确，请重新选择' }; return }
            $now = Get-Date
            if ($sd -lt $now.AddSeconds($SchedMinSeconds)) { Send-Json $res @{ success = $false; msg = ('定时时间需在 ' + [int]($SchedMinSeconds / 60) + ' 分钟之后') }; return }
            if ($sd -gt $now.AddDays($SchedMaxDays)) { Send-Json $res @{ success = $false; msg = ('定时时间不能超过 ' + $SchedMaxDays + ' 天') }; return }
            $sched = AsArray (Get-PropSafe $u 'scheduledMails' @())
            if ($sched.Count -ge $MaxScheduled) { Send-Json $res @{ success = $false; msg = ('定时任务最多 ' + $MaxScheduled + ' 条，请先清理不再需要的任务') }; return }
            $entry = @{
                id          = [Guid]::NewGuid().ToString('N')
                to          = (('' + $b.to).Trim())
                cc          = (('' + $b.cc).Trim())
                subject     = $subject
                content     = $content
                attachments = $attChk.list
                sendTime    = $sd.ToString('yyyy-MM-dd HH:mm:ss')
                created     = (Get-Now)
            }
            Set-Prop $u 'scheduledMails' (@($sched) + $entry)
            Save-Database
            Write-Log ('新建定时邮件: ' + $u.username + ' -> ' + ($toNames -join ',') + ' 「' + $subject + '」将于 ' + $entry.sendTime + ' 发送') 'Yellow'
            Send-Json $res @{ success = $true; msg = ('定时任务已创建，将于 ' + $entry.sendTime + ' 自动发送'); sendTime = $entry.sendTime }
        }

        'schedulelist' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $tasks = @()
            $sched = AsArray (Get-PropSafe $u 'scheduledMails' @())
            foreach ($t in $sched) {
                $atts = AsArray (Get-PropSafe $t 'attachments' @())
                $ct = ('' + (Get-PropSafe $t 'content' ''))
                if ($ct.Length -gt 80) { $ct = $ct.Substring(0, 80) + '…' }
                $tasks += @{
                    id       = ('' + (Get-PropSafe $t 'id' ''))
                    to       = (Get-DisplayAddr ('' + (Get-PropSafe $t 'to' '')))
                    cc       = (Get-DisplayAddr ('' + (Get-PropSafe $t 'cc' '')))
                    subject  = ('' + (Get-PropSafe $t 'subject' '(无主题)'))
                    excerpt  = $ct
                    attCount = $atts.Count
                    sendTime = ('' + (Get-PropSafe $t 'sendTime' ''))
                    created  = ('' + (Get-PropSafe $t 'created' ''))
                }
            }
            $tasks = @($tasks | Sort-Object -Property { $_.sendTime })
            Send-Json $res @{ success = $true; tasks = $tasks; max = $MaxScheduled }
        }

        'schedulecancel' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $tid = ('' + $b.id)
            $sched = AsArray (Get-PropSafe $u 'scheduledMails' @())
            $found = $false
            foreach ($t in $sched) { if (('' + $t.id) -eq $tid) { $found = $true; break } }
            if (-not $found) { Send-Json $res @{ success = $false; msg = '定时任务不存在或已取消' }; return }
            Set-Prop $u 'scheduledMails' (@($sched | Where-Object { ('' + $_.id) -ne $tid }))
            Save-Database
            Write-Log ('取消定时邮件: ' + $u.username) 'DarkGray'
            Send-Json $res @{ success = $true; msg = '定时任务已取消' }
        }

        'schedulesendnow' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $tid = ('' + $b.id)
            $sched = AsArray (Get-PropSafe $u 'scheduledMails' @())
            $target = $null
            foreach ($t in $sched) { if (('' + $t.id) -eq $tid) { $target = $t; break } }
            if ($null -eq $target) { Send-Json $res @{ success = $false; msg = '定时任务不存在或已发送' }; return }
            $subject = ('' + (Get-PropSafe $target 'subject' '(无主题)'))
            $r2 = Invoke-DeliverMail $u ('' + (Get-PropSafe $target 'to' '')) ('' + (Get-PropSafe $target 'cc' '')) $subject ('' + (Get-PropSafe $target 'content' '')) (Get-PropSafe $target 'attachments' @())
            Set-Prop $u 'scheduledMails' (@($sched | Where-Object { ('' + $_.id) -ne $tid }))
            if ([bool]($r2.ok)) {
                Save-Database
                $rejected = @($r2.rejected)
                $msg = ('已立即发送给 ' + @($r2.delivered).Count + ' 位收件人')
                if ($rejected.Count -gt 0) { $msg += ('；' + ($rejected -join '、') + ' 拒收（黑名单）') }
                Write-Log ('定时邮件立即发送: ' + $u.username + ' 「' + $subject + '」') 'Yellow'
                Send-Json $res @{ success = $true; msg = $msg }
            } else {
                Save-Database
                Send-Json $res @{ success = $false; msg = ('发送失败，任务已移除：' + ('' + $r2.msg)) }
            }
        }

        # ---------- 自定义分类箱 ----------
        'boxcreate' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $chk = Test-CustomBoxName ('' + $b.name)
            if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
            $cbs = AsArray (Get-PropSafe $u 'customBoxes' @())
            if ($cbs.Count -ge $MaxCustomBoxes) { Send-Json $res @{ success = $false; msg = ('最多可创建 ' + $MaxCustomBoxes + ' 个分类箱') }; return }
            foreach ($cb in $cbs) {
                if (('' + $cb.name) -eq $chk.name) { Send-Json $res @{ success = $false; msg = '已存在同名分类箱「' + $chk.name + '」' }; return }
            }
            $nb = @{ id = [Guid]::NewGuid().ToString('N'); name = $chk.name; salt = ''; hash = ''; created = (Get-Now) }
            Set-Prop $u 'customBoxes' (@($cbs) + $nb)
            Set-Prop $u.mails ('cb_' + $nb.id) @()
            Save-Database
            Write-Log ('新建分类箱: ' + $u.username + ' / ' + $chk.name) 'DarkGray'
            Send-Json $res @{ success = $true; msg = ('分类箱「' + $chk.name + '」已创建'); id = ('' + $nb.id) }
        }

        'boxrename' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $cb = Find-CustomBox $u ('' + $b.id)
            if ($null -eq $cb) { Send-Json $res @{ success = $false; msg = '分类箱不存在' }; return }
            $chk = Test-CustomBoxName ('' + $b.name)
            if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
            $cbs = AsArray (Get-PropSafe $u 'customBoxes' @())
            foreach ($x in $cbs) {
                if (('' + $x.id) -ne ('' + $cb.id) -and ('' + $x.name) -eq $chk.name) { Send-Json $res @{ success = $false; msg = '已存在同名分类箱「' + $chk.name + '」' }; return }
            }
            $old = '' + $cb.name
            Set-Prop $cb 'name' $chk.name
            Save-Database
            Send-Json $res @{ success = $true; msg = ('已重命名为「' + $chk.name + '」'); old = $old }
        }

        'boxdelete' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $bid = ('' + $b.id)
            $cb = Find-CustomBox $u $bid
            if ($null -eq $cb) { Send-Json $res @{ success = $false; msg = '分类箱不存在' }; return }
            $key = 'cb_' + $bid
            $lst = AsArray (Get-PropSafe $u.mails $key @())
            if ($lst.Count -gt 0 -and -not [bool]($b.confirm -eq $true)) {
                Send-Json $res @{ success = $false; needConfirm = $true; count = $lst.Count; msg = ('该分类箱内有 ' + $lst.Count + ' 封邮件，删除后邮件将移入【已删除】，确定继续吗？') }
                return
            }
            foreach ($m in $lst) { Set-Prop $m 'origin' $key }
            $trashList = AsArray (Get-PropSafe $u.mails 'trash' @())
            $u.mails.trash = @($trashList) + @($lst)
            Remove-Prop $u.mails $key
            Set-Prop $u 'customBoxes' (@(AsArray (Get-PropSafe $u 'customBoxes' @()) | Where-Object { ('' + $_.id) -ne $bid }))
            if ($null -ne $s.unlocked) { try { $s.unlocked.Remove($bid) | Out-Null } catch {} }
            Save-Database
            Write-Log ('删除分类箱: ' + $u.username + ' / ' + ('' + $cb.name) + '（' + $lst.Count + ' 封邮件移入已删除）') 'DarkGray'
            Send-Json $res @{ success = $true; msg = ('分类箱「' + ('' + $cb.name) + '」已删除' + $(if ($lst.Count -gt 0) { '，箱内 ' + $lst.Count + ' 封邮件已移入【已删除】' } else { '' })) }
        }

        'boxsetpwd' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $bid = ('' + $b.id)
            $cb = Find-CustomBox $u $bid
            if ($null -eq $cb) { Send-Json $res @{ success = $false; msg = '分类箱不存在' }; return }
            $curHash = ('' + (Get-PropSafe $cb 'hash' ''))
            if ($curHash -ne '') {
                $old = '' + $b.oldpwd
                if ((Get-PwdHash $old ('' + (Get-PropSafe $cb 'salt' ''))) -ne $curHash) {
                    Send-Json $res @{ success = $false; msg = '原密码不正确，无法修改' }; return
                }
            }
            $new = '' + $b.newpwd
            if ($new -eq '') {
                Set-Prop $cb 'salt' ''
                Set-Prop $cb 'hash' ''
                if ($null -ne $s.unlocked) { try { $s.unlocked.Remove($bid) | Out-Null } catch {} }
                Save-Database
                Write-Log ('清除分类箱密码: ' + $u.username) 'DarkGray'
                Send-Json $res @{ success = $true; msg = '已清除该分类箱的密码，任何人登录后均可直接查看' }
                return
            }
            if ($new.Length -lt 4 -or $new.Length -gt 16 -or $new -match '\s') { Send-Json $res @{ success = $false; msg = '分类箱密码需为 4-16 位且不含空格' }; return }
            Set-Prop $cb 'salt' ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $cb 'hash' (Get-PwdHash $new (Get-PropSafe $cb 'salt' ''))
            if ($null -ne $s.unlocked) { try { [void]$s.unlocked.Add($bid) } catch {} }
            Save-Database
            Write-Log ('设置分类箱密码: ' + $u.username) 'DarkGray'
            Send-Json $res @{ success = $true; msg = '密码已设置并解锁，退出登录后需重新输入密码' }
        }

        'boxunlock' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $bid = ('' + $b.id)
            $cb = Find-CustomBox $u $bid
            if ($null -eq $cb) { Send-Json $res @{ success = $false; msg = '分类箱不存在' }; return }
            $curHash = ('' + (Get-PropSafe $cb 'hash' ''))
            if ($curHash -eq '') { Send-Json $res @{ success = $true; msg = '该分类箱未设置密码' }; return }
            $pwd = '' + $b.pwd
            if ((Get-PwdHash $pwd ('' + (Get-PropSafe $cb 'salt' ''))) -ne $curHash) {
                Send-Json $res @{ success = $false; msg = '密码不正确，请重试' }; return
            }
            if ($null -ne $s.unlocked) { try { [void]$s.unlocked.Add($bid) } catch {} }
            Send-Json $res @{ success = $true; msg = '解锁成功' }
        }

        'boxlock' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $bid = ('' + $b.id)
            if ($null -ne $s.unlocked) { try { $s.unlocked.Remove($bid) | Out-Null } catch {} }
            Send-Json $res @{ success = $true; msg = '已重新上锁' }
        }

        # ---------- 黑名单 ----------
        'blacklist' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $list = @()
            foreach ($n in (AsArray (Get-PropSafe $u 'blacklist' @()))) {
                $t = Find-User (('' + $n))
                if ($null -eq $t) { continue }
                $list += @{ username = ('' + $t.username); nickname = ('' + (Get-PropSafe $t 'nickname' '')) }
            }
            $list = @($list | Sort-Object -Property { $_.username })
            Send-Json $res @{ success = $true; list = $list; max = $MaxBlacklist }
        }

        'blackadd' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $name = (('' + $b.name).Trim().ToLower() -replace '@.*$', '')
            if ($name -eq '') { Send-Json $res @{ success = $false; msg = '请指定要拉黑的账号' }; return }
            if ($name -eq ('' + $u.username)) { Send-Json $res @{ success = $false; msg = '不能拉黑自己' }; return }
            $tu = Find-User $name
            if ($null -eq $tu) { Send-Json $res @{ success = $false; msg = '对方不是本系统学生账号，无法拉黑（教师通知不受黑名单限制）' }; return }
            $bl = AsArray (Get-PropSafe $u 'blacklist' @())
            if ($bl -contains $name) { Send-Json $res @{ success = $false; msg = '该同学已在你的黑名单中' }; return }
            if ($bl.Count -ge $MaxBlacklist) { Send-Json $res @{ success = $false; msg = ('黑名单最多 ' + $MaxBlacklist + ' 人') }; return }
            Set-Prop $u 'blacklist' (@($bl) + $name)
            Save-Database
            Write-Log ('黑名单: ' + $u.username + ' 拉黑了 ' + $name) 'DarkYellow'
            Send-Json $res @{ success = $true; msg = ('已将「' + ('' + (Get-PropSafe $tu 'nickname' $name)) + '」加入黑名单，对方将无法给你发信') }
        }

        'blackremove' {
            $s = Get-Session ('' + $b.token) 'student'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效，请重新登录' }; return }
            $u = Find-User $s.user
            if ($null -eq $u) { Send-Json $res @{ success = $false; needLogin = $true; msg = '账号不存在' }; return }
            $name = (('' + $b.name).Trim().ToLower() -replace '@.*$', '')
            $bl = AsArray (Get-PropSafe $u 'blacklist' @())
            if (-not ($bl -contains $name)) { Send-Json $res @{ success = $false; msg = '该同学不在你的黑名单中' }; return }
            Set-Prop $u 'blacklist' (@($bl | Where-Object { $_ -ne $name }))
            Save-Database
            Write-Log ('黑名单: ' + $u.username + ' 移出了 ' + $name) 'DarkYellow'
            Send-Json $res @{ success = $true; msg = '已移出黑名单，对方现在可以给你发信了' }
        }

        # ---------- 教师端：登录 / 找回 ----------
        'tlogin' {
            $name = ('' + $b.username).Trim()
            $pwd  = '' + $b.password
            $cfg = Get-ServerSettings
            $tuser = ('' + (Get-PropSafe $cfg 'teacherUser' 'admin'))
            $tsalt = ('' + (Get-PropSafe $cfg 'teacherSalt' ''))
            $thash = ('' + (Get-PropSafe $cfg 'teacherHash' ''))
            if ($name -eq $tuser -and ((Get-PwdHash $pwd $tsalt) -eq $thash)) {
                $token = New-Session $tuser 'teacher'
                Write-Log ('教师登录管理后台（' + $tuser + '）') 'Magenta'
                Send-Json $res @{ success = $true; token = $token; domain = $Script:CurDomain }
            } else {
                Send-Json $res @{ success = $false; msg = '管理员账号或密码错误' }
            }
        }

        'tsecquestion' {
            $cfg = Get-ServerSettings
            $q = ('' + (Get-PropSafe $cfg 'secQuestion' ''))
            $has = ('' + (Get-PropSafe $cfg 'secAnswerHash' '')) -ne ''
            Send-Json $res @{ success = $true; hasSecurity = $has; question = $(if ($has) { $q } else { '' }) }
        }

        'tforgotreset' {
            $now = Get-Date
            if ($now -lt $Script:ForgotLock.until) {
                $left = [int][Math]::Ceiling(($Script:ForgotLock.until - $now).TotalSeconds)
                Send-Json $res @{ success = $false; msg = ('尝试次数过多，已临时锁定，请 ' + $left + ' 秒后再试') }; return
            }
            $np = '' + $b.newpwd
            if ($np.Length -lt 5 -or $np.Length -gt 16 -or $np -match '\s') { Send-Json $res @{ success = $false; msg = '新密码需为 5-16 位且不含空格' }; return }
            $cfg = Get-ServerSettings
            $mode = ('' + $b.mode).Trim().ToLower()
            $ok = $false
            if ($mode -eq 'sec') {
                $hash = ('' + (Get-PropSafe $cfg 'secAnswerHash' ''))
                if ($hash -eq '') { Send-Json $res @{ success = $false; msg = '尚未设置密保问题，请改用应急码方式找回' }; return }
                $ans = Get-PwdHash ((('' + $b.answer).Trim().ToLower())) ('' + (Get-PropSafe $cfg 'secAnswerSalt' ''))
                if ($ans -eq $hash) { $ok = $true } else {
                    $Script:ForgotLock.count++
                }
            } else {
                if ([string]::IsNullOrWhiteSpace($EmergencyResetCode)) { Send-Json $res @{ success = $false; msg = '应急码功能未启用' }; return }
                if (('' + $b.code).Trim() -eq $EmergencyResetCode) { $ok = $true } else {
                    $Script:ForgotLock.count++
                }
            }
            if (-not $ok) {
                if ($Script:ForgotLock.count -ge 5) {
                    $Script:ForgotLock.until = $now.AddMinutes(10)
                    $Script:ForgotLock.count = 0
                    Write-Log '教师密码找回：连续错误 5 次，临时锁定 10 分钟' 'Red'
                    Send-Json $res @{ success = $false; msg = '连续错误 5 次，已锁定 10 分钟，请稍后再试' }
                } else {
                    $left = (5 - $Script:ForgotLock.count)
                    Send-Json $res @{ success = $false; msg = ('验证失败，还可尝试 ' + $left + ' 次') }
                }
                return
            }
            $Script:ForgotLock.count = 0
            $Script:ForgotLock.until = [datetime]::MinValue
            Set-Prop $cfg 'teacherSalt' ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $cfg 'teacherHash' (Get-PwdHash $np (Get-PropSafe $cfg 'teacherSalt' ''))
            Clear-TeacherSessions
            Save-Database
            Write-Log ('教师密码已通过' + $(if ($mode -eq 'sec') { '密保问题' } else { '应急码' }) + '找回重置') 'Magenta'
            Send-Json $res @{ success = $true; msg = '密码已重置，请使用新密码登录' }
        }

        # ---------- 教师端：数据 / 设置 ----------
        'tdata' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $stat = Get-UserStatList
            $cfg = Get-ServerSettings
            $groupsArr = AsArray (Get-PropSafe $Script:Db 'groups' @())
            Send-Json $res @{
                success  = $true
                domain   = $Script:CurDomain
                groups   = $groupsArr
                users    = $stat.list
                settings = @{
                    regCaptcha    = [bool](Get-PropSafe $cfg 'regCaptcha' $true)
                    regSmsCode    = [bool](Get-PropSafe $cfg 'regSmsCode' $false)
                    pwdComplexity = [int](Get-PropSafe $cfg 'pwdComplexity' 0)
                    domain        = $Script:CurDomain
                    hasSecurity   = (('' + (Get-PropSafe $cfg 'secAnswerHash' '')) -ne '')
                }
                stats    = @{ totalUsers = $stat.totalUsers; totalMails = $stat.totalMails; todayReg = $stat.todayReg; todayLogin = $stat.todayLogin; online = $stat.online }
            }
        }

        'tsavesettings' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $cfg = Get-ServerSettings
            $dom = (('' + $b.domain).Trim().ToLower())
            if ($dom -notmatch '^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$' -or $dom.Length -gt 40) {
                Send-Json $res @{ success = $false; msg = '邮箱域名格式不正确（如 163.com 或 mail.school.edu.cn）' }; return
            }
            $oldDomain = $Script:CurDomain
            Set-Prop $cfg 'regCaptcha' ([bool]($b.regCaptcha -eq $true))
            Set-Prop $cfg 'regSmsCode' ([bool]($b.regSmsCode -eq $true))
            $lvl = 0
            try { $lvl = [int]$b.pwdComplexity } catch { $lvl = 0 }
            if ($lvl -lt 0 -or $lvl -gt 2) { $lvl = 0 }
            Set-Prop $cfg 'pwdComplexity' $lvl
            Set-Prop $cfg 'domain' $dom
            $Script:CurDomain = $dom
            Save-Database
            $domNote = ''
            if ($dom -ne $oldDomain) { $domNote = '；邮箱域名已从 ' + $oldDomain + ' 改为 ' + $dom }
            Write-Log ('教师更新设置（图形验证码: ' + (Get-PropSafe $cfg 'regCaptcha' $true) + '，虚拟短信: ' + (Get-PropSafe $cfg 'regSmsCode' $false) + '，密码复杂度: ' + (Get-PropSafe $cfg 'pwdComplexity' 0) + '，域名: ' + $dom + '）') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('设置已保存并立即生效' + $domNote) }
        }

        'tchangepwd' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $cfg = Get-ServerSettings
            $old = '' + $b.oldpwd
            $new = '' + $b.newpwd
            $tsalt = ('' + (Get-PropSafe $cfg 'teacherSalt' ''))
            $thash = ('' + (Get-PropSafe $cfg 'teacherHash' ''))
            if ((Get-PwdHash $old $tsalt) -ne $thash) { Send-Json $res @{ success = $false; msg = '当前密码不正确' }; return }
            if ($new.Length -lt 5 -or $new.Length -gt 16 -or $new -match '\s') { Send-Json $res @{ success = $false; msg = '新密码需为 5-16 位且不含空格' }; return }
            if ($new -eq $old) { Send-Json $res @{ success = $false; msg = '新密码不能与当前密码相同' }; return }
            Set-Prop $cfg 'teacherSalt' ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $cfg 'teacherHash' (Get-PwdHash $new (Get-PropSafe $cfg 'teacherSalt' ''))
            Clear-TeacherSessions
            Save-Database
            Write-Log '教师修改了管理后台密码（全部登录已失效，需重新登录）' 'Magenta'
            Send-Json $res @{ success = $true; msg = '密码修改成功，请使用新密码重新登录' }
        }

        'tsetsecurity' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $cfg = Get-ServerSettings
            $pwd = '' + $b.password
            $tsalt = ('' + (Get-PropSafe $cfg 'teacherSalt' ''))
            $thash = ('' + (Get-PropSafe $cfg 'teacherHash' ''))
            if ((Get-PwdHash $pwd $tsalt) -ne $thash) { Send-Json $res @{ success = $false; msg = '当前密码不正确，无法修改密保问题' }; return }
            $q = ('' + $b.question).Trim()
            $a = ('' + $b.answer).Trim()
            if ($q -eq '' -or $q.Length -gt 50) { Send-Json $res @{ success = $false; msg = '密保问题需为 1-50 个字符' }; return }
            if ($a -eq '' -or $a.Length -gt 30) { Send-Json $res @{ success = $false; msg = '密保答案需为 1-30 个字符' }; return }
            Set-Prop $cfg 'secQuestion'    $q
            Set-Prop $cfg 'secAnswerSalt'  ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $cfg 'secAnswerHash'  (Get-PwdHash $a.ToLower() (Get-PropSafe $cfg 'secAnswerSalt' ''))
            Save-Database
            Write-Log '教师更新了密保问题（答案已加密保存）' 'Magenta'
            Send-Json $res @{ success = $true; msg = '密保问题已保存，忘记密码时可凭答案找回' }
        }

        # ---------- 教师端：班级管理 ----------
        'taddgroup' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $chk = Test-GroupName ('' + $b.name)
            if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
            $groups = AsArray (Get-PropSafe $Script:Db 'groups' @())
            if ($groups -contains $chk.name) { Send-Json $res @{ success = $false; msg = '班级「' + $chk.name + '」已存在' }; return }
            Set-Prop $Script:Db 'groups' (@($groups) + $chk.name)
            Save-Database
            Write-Log ('教师新建班级: ' + $chk.name) 'Magenta'
            Send-Json $res @{ success = $true; msg = ('班级「' + $chk.name + '」已创建') }
        }

        'trenamegroup' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $old = ('' + $b.old).Trim()
            $chk = Test-GroupName ('' + $b.name)
            if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
            $groups = AsArray (Get-PropSafe $Script:Db 'groups' @())
            if (-not ($groups -contains $old)) { Send-Json $res @{ success = $false; msg = '原班级不存在' }; return }
            if ($old -ne $chk.name -and ($groups -contains $chk.name)) { Send-Json $res @{ success = $false; msg = '班级「' + $chk.name + '」已存在' }; return }
            $newList = @()
            foreach ($g in $groups) { if ($g -eq $old) { $newList += $chk.name } else { $newList += $g } }
            Set-Prop $Script:Db 'groups' $newList
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if (('' + (Get-PropSafe $u 'group' '')) -eq $old) { Set-Prop $u 'group' $chk.name }
            }
            Save-Database
            Write-Log ('教师重命名班级: ' + $old + ' → ' + $chk.name) 'Magenta'
            Send-Json $res @{ success = $true; msg = ('已重命名为「' + $chk.name + '」') }
        }

        'tdelgroup' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $name = ('' + $b.name).Trim()
            $groups = AsArray (Get-PropSafe $Script:Db 'groups' @())
            if (-not ($groups -contains $name)) { Send-Json $res @{ success = $false; msg = '班级不存在' }; return }
            $newList = @()
            foreach ($g in $groups) { if ($g -ne $name) { $newList += $g } }
            Set-Prop $Script:Db 'groups' $newList
            $cnt = 0
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if (('' + (Get-PropSafe $u 'group' '')) -eq $name) { Set-Prop $u 'group' ''; $cnt++ }
            }
            Save-Database
            Write-Log ('教师删除班级: ' + $name + '（' + $cnt + ' 个学生变为未分组）') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('班级「' + $name + '」已删除，' + $cnt + ' 个学生变为未分组') }
        }

        'tsetgroup' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $target = ('' + $b.target).Trim()
            if ($target -ne '') {
                $chk = Test-GroupName $target
                if (-not $chk.ok) { Send-Json $res @{ success = $false; msg = $chk.msg }; return }
                $target = $chk.name
            }
            $targets = Select-TargetUsers $b
            if ($targets.Count -eq 0) { Send-Json $res @{ success = $false; msg = '未选择任何账号' }; return }
            if ($target -ne '') {
                $groups = AsArray (Get-PropSafe $Script:Db 'groups' @())
                if (-not ($groups -contains $target)) {
                    Set-Prop $Script:Db 'groups' (@($groups) + $target)
                }
            }
            $cnt = 0
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if ($targets.Contains(('' + $u.username))) { Set-Prop $u 'group' $target; $cnt++ }
            }
            Save-Database
            $msg = $(if ($target -eq '') { ('已将 ' + $cnt + ' 个账号移出所有班级') } else { ('已将 ' + $cnt + ' 个账号移动到「' + $target + '」') })
            Write-Log ('教师批量设置班级（' + $cnt + ' 个）') 'Magenta'
            Send-Json $res @{ success = $true; msg = $msg; count = $cnt }
        }

        'tbatchreset' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $np = '' + $b.newpwd
            if ($np.Length -lt 6 -or $np.Length -gt 16 -or $np -match '\s') { Send-Json $res @{ success = $false; msg = '新密码需为 6-16 位且不含空格' }; return }
            $targets = Select-TargetUsers $b
            if ($targets.Count -eq 0) { Send-Json $res @{ success = $false; msg = '未选择任何账号' }; return }
            $cnt = 0
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if ($targets.Contains(('' + $u.username))) {
                    Set-Prop $u 'salt'         ([Guid]::NewGuid().ToString('N').Substring(0, 16))
                    Set-Prop $u 'passwordHash' (Get-PwdHash $np (Get-PropSafe $u 'salt' ''))
                    $cnt++
                }
            }
            Save-Database
            Write-Log ('教师批量重置密码（' + $cnt + ' 个账号）') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('已重置 ' + $cnt + ' 个账号的密码为 ' + $np); count = $cnt }
        }

        'tbatchdel' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $targets = Select-TargetUsers $b
            if ($targets.Count -eq 0) { Send-Json $res @{ success = $false; msg = '未选择任何账号' }; return }
            $delSet = $targets
            $kept = @()
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if ($delSet.Contains(('' + $u.username))) { continue }
                $kept += $u
            }
            $Script:Db.users = $kept
            foreach ($k in @($Script:Sessions.Keys)) {
                if ($Script:Sessions[$k].role -eq 'student' -and $delSet.Contains($Script:Sessions[$k].user)) { $Script:Sessions.Remove($k) | Out-Null }
            }
            Save-Database
            Write-Log ('教师批量删除账号（' + $delSet.Count + ' 个）') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('已删除 ' + $delSet.Count + ' 个账号及其全部邮件数据'); count = $delSet.Count }
        }

        # ---------- 教师端：导出 ----------
        'texport' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $fmt = ('' + $b.format).Trim().ToLower()
            if (@('xlsx', 'xls', 'csv') -notcontains $fmt) { $fmt = 'xlsx' }
            $stat = Get-UserStatList
            $outRows = New-Object System.Collections.Generic.List[object]
            [void]$outRows.Add(@('序号', '学生账号', '邮箱地址', '昵称', '班级', '手机号', '注册时间', '最近登录', '最近登录IP', '收件箱', '未读', '已发送', '草稿箱', '垃圾邮件', '已删除'))
            $i = 0
            foreach ($u in $stat.list) {
                $i++
                [void]$outRows.Add(@($i, ('' + $u.username), (('' + $u.username) + '@' + $Script:CurDomain), ('' + $u.nickname), ('' + $u.group), ('' + $u.phone), ('' + $u.createTime), ('' + $u.lastLoginTime), ('' + $u.lastLoginIp), [int]$u.inbox, [int]$u.unread, [int]$u.sent, [int]$u.draft, [int]$u.junk, [int]$u.trash))
            }
            $rowsArr = @($outRows.ToArray())
            $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
            try {
                switch ($fmt) {
                    'xlsx' {
                        $bytes = New-XlsxFile $rowsArr '学生名单'
                        $fname = ('学生邮箱名单_' + $stamp + '.xlsx')
                        $mime  = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                    }
                    'xls' {
                        $bytes = New-XlsFile $rowsArr '学生名单'
                        $fname = ('学生邮箱名单_' + $stamp + '.xls')
                        $mime  = 'application/vnd.ms-excel'
                    }
                    default {
                        $bytes = New-CsvFile $rowsArr
                        $fname = ('学生邮箱名单_' + $stamp + '.csv')
                        $mime  = 'text/csv'
                    }
                }
            } catch {
                Send-Json $res @{ success = $false; msg = ('生成文件失败: ' + $_.Exception.Message) }; return
            }
            Write-Log ('教师导出学生名单（' + $fmt + '，' + $i + ' 条）') 'Magenta'
            Send-Json $res @{ success = $true; filename = $fname; mime = $mime; data = [Convert]::ToBase64String($bytes) }
        }

        # ---------- 教师端：批量导入 ----------
        'timportusers' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $fname = ('' + $b.filename)
            $b64 = ('' + $b.data).Trim()
            if ($b64 -eq '') { Send-Json $res @{ success = $false; msg = '未收到文件数据' }; return }
            if ($b64.Length -gt 10MB) { Send-Json $res @{ success = $false; msg = '文件过大（超过 8MB）' }; return }
            $bytes = $null
            try { $bytes = [Convert]::FromBase64String($b64) } catch { Send-Json $res @{ success = $false; msg = '文件数据无效' }; return }
            if ($null -eq $bytes -or $bytes.Length -eq 0) { Send-Json $res @{ success = $false; msg = '文件内容为空' }; return }
            try {
                $parsed = Parse-ImportFile $fname $bytes
            } catch {
                Send-Json $res @{ success = $false; msg = ('解析失败: ' + $_.Exception.Message) }; return
            }
            $rows = AsArray $parsed.rows
            $dataRows = @()
            foreach ($r in $rows) {
                $arr = @()
                foreach ($c in (AsArray $r)) { $arr += ('' + $c) }
                $hasContent = $false
                foreach ($c in $arr) { if ($c.Trim() -ne '') { $hasContent = $true; break } }
                if ($hasContent) { $dataRows += ,@($arr) }
            }
            if ($dataRows.Count -lt 2) { Send-Json $res @{ success = $false; msg = '表格中没有可导入的数据行（第一行为表头，数据从第二行开始）' }; return }
            if (($dataRows.Count - 1) -gt $ImportMaxRows) {
                Send-Json $res @{ success = $false; msg = ('单次最多导入 ' + $ImportMaxRows + ' 行数据（当前 ' + ($dataRows.Count - 1) + ' 行），请分批导入') }; return
            }
            $userAliases  = @('学生账号', '账号', '用户名', '邮箱账号', '邮箱地址', 'username', 'email', 'mail', '登录账号', '学生邮箱', 'user', 'userid', 'login', '帐号', '账户')
            $nickAliases  = @('昵称', '姓名', '学生姓名', 'nickname', 'name', '称呼')
            $grpAliases   = @('班级', '分组', '组', '班级名称', '班', 'class', 'group', 'classname')
            $phoneAliases = @('手机号', '手机', '电话', 'phone', 'mobile', '手机号码', '联系电话', '电话号码')
            $pwdAliases   = @('密码', '初始密码', 'password', 'pwd', '登录密码')
            $header = @($dataRows[0] | ForEach-Object { (('' + $_).Trim().ToLower() -replace '\s', '') })
            $colUser = -1; $colNick = -1; $colGrp = -1; $colPhone = -1; $colPwd = -1
            for ($hi = 0; $hi -lt $header.Count; $hi++) {
                $h = $header[$hi]
                if ($colUser -lt 0 -and ($userAliases -contains $h)) { $colUser = $hi; continue }
                if ($colNick -lt 0 -and ($nickAliases -contains $h)) { $colNick = $hi; continue }
                if ($colGrp -lt 0 -and ($grpAliases -contains $h)) { $colGrp = $hi; continue }
                if ($colPhone -lt 0 -and ($phoneAliases -contains $h)) { $colPhone = $hi; continue }
                if ($colPwd -lt 0 -and ($pwdAliases -contains $h)) { $colPwd = $hi }
            }
            if ($colUser -lt 0) {
                Send-Json $res @{ success = $false; msg = ('未能识别账号列。表头需包含以下任一名称：' + ($userAliases -join ' / ')) }; return
            }
            $getCell = {
                param($arr, $idx)
                if ($idx -ge 0 -and $null -ne $arr -and $idx -lt $arr.Count) { return ('' + $arr[$idx]).Trim() }
                return ''
            }
            $imported = 0; $failed = 0
            $errors = New-Object System.Collections.Generic.List[object]
            $newUsers = New-Object System.Collections.Generic.List[object]
            $grpNames = New-Object System.Collections.Generic.List[string]
            for ($ri = 1; $ri -lt $dataRows.Count; $ri++) {
                $srcRow = $ri + 1
                $rowArr = $dataRows[$ri]
                $rawUser = & $getCell $rowArr $colUser
                $name = (($rawUser -replace '＠', '@') -split '@')[0].Trim().ToLower()
                if ($name -eq '') {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = ''; reason = '账号为空' })
                    continue
                }
                $chk = Test-Username $name
                if (-not $chk.ok) {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = $name; reason = $chk.msg })
                    continue
                }
                $nick = & $getCell $rowArr $colNick
                if ($nick -eq '') { $nick = $name }
                if ($nick.Length -gt 12) {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = $name; reason = '昵称最多 12 个字符' })
                    continue
                }
                $grp = & $getCell $rowArr $colGrp
                if ($grp -ne '') {
                    if ($grp.Length -gt 20) {
                        $failed++
                        $errors.Add(@{ row = $srcRow; user = $name; reason = '班级名最多 20 个字符' })
                        continue
                    }
                    if ($grp -match "[,;`"`']") {
                        $failed++
                        $errors.Add(@{ row = $srcRow; user = $name; reason = '班级名不能包含逗号/分号/引号' })
                        continue
                    }
                    if (-not $grpNames.Contains($grp)) { $grpNames.Add($grp) }
                }
                $phone = & $getCell $rowArr $colPhone
                if ($phone -ne '' -and $phone -notmatch '^1\d{10}$') {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = $name; reason = '手机号格式不正确（需 11 位、1 开头）' })
                    continue
                }
                $pwd = & $getCell $rowArr $colPwd
                if ($pwd -eq '') { $pwd = $ImportDefaultPwd }
                if ($pwd.Length -lt 6 -or $pwd.Length -gt 16) {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = $name; reason = '密码需为 6-16 位' })
                    continue
                }
                if ($pwd -match '\s') {
                    $failed++
                    $errors.Add(@{ row = $srcRow; user = $name; reason = '密码不能包含空格' })
                    continue
                }
                $newUsers.Add((New-User $name $pwd $nick $phone $grp))
                $imported++
            }
            $createdGroups = @()
            if ($imported -gt 0) {
                $curGroups = AsArray (Get-PropSafe $Script:Db 'groups' @())
                foreach ($g in $grpNames) {
                    if (-not ($curGroups -contains $g)) { $curGroups = @($curGroups) + $g; $createdGroups += $g }
                }
                Set-Prop $Script:Db 'groups' $curGroups
                $userList = AsArray $Script:Db.users
                $Script:Db.users = @($userList) + @($newUsers.ToArray())
                Save-Database
            }
            $errorsShow = @($errors | Select-Object -First 30)
            Write-Log ('教师批量导入账号（来源: ' + ('' + $parsed.kind) + '）：成功 ' + $imported + '，失败 ' + $failed + '，新建班级 ' + $createdGroups.Count) 'Magenta'
            Send-Json $res @{
                success       = $true
                totalRows     = ($dataRows.Count - 1)
                imported      = $imported
                failed        = $failed
                errorTotal    = $errors.Count
                errors        = $errorsShow
                defaultPwd    = $ImportDefaultPwd
                kind          = ('' + $parsed.kind)
                createdGroups = $createdGroups
            }
        }

        'tbroadcast' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $subject = ('' + $b.subject).Trim()
            if ($subject -eq '') { $subject = '(无主题)' }
            $content = '' + $b.content
            if ($content.Trim() -eq '') { Send-Json $res @{ success = $false; msg = '通知内容不能为空' }; return }
            $count = 0
            $userList = AsArray $Script:Db.users
            foreach ($u in $userList) {
                if ($null -eq $u) { continue }
                $inboxList = AsArray (Get-PropSafe $u.mails 'inbox' @())
                $u.mails.inbox = @($inboxList) + (New-MailObj ('teacher@' + $Script:CurDomain) '教师通知' (('' + $u.username) + '@' + $Script:CurDomain) '' $subject $content @() $false)
                $count++
            }
            if ($count -gt 0) { Save-Database }
            Write-Log ('教师发送系统通知「' + $subject + '」给 ' + $count + ' 位学生') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('通知已发送给 ' + $count + ' 位学生') }
        }

        'tdeluser' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $name = ('' + $b.username).Trim().ToLower()
            if ($null -eq (Find-User $name)) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            $userList = AsArray $Script:Db.users
            $Script:Db.users = @($userList | Where-Object { $_.username -ne $name })
            $keys = @()
            foreach ($k in @($Script:Sessions.Keys)) {
                if ($Script:Sessions[$k].role -eq 'student' -and $Script:Sessions[$k].user -eq $name) { $keys += $k }
            }
            foreach ($k in $keys) { $Script:Sessions.Remove($k) | Out-Null }
            Save-Database
            Write-Log ('教师删除学生账号: ' + $name) 'Magenta'
            Send-Json $res @{ success = $true; msg = ('已删除学生账号 ' + $name) }
        }

        'tresetpwd' {
            $s = Get-Session ('' + $b.token) 'teacher'
            if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
            $name = ('' + $b.username).Trim().ToLower()
            $np = '' + $b.newpwd
            $u = Find-User $name
            if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
            if ($np.Length -lt 6 -or $np.Length -gt 16 -or $np -match '\s') { Send-Json $res @{ success = $false; msg = '新密码需为 6-16 个字符且不含空格' }; return }
            Set-Prop $u 'salt'         ([Guid]::NewGuid().ToString('N').Substring(0, 16))
            Set-Prop $u 'passwordHash' (Get-PwdHash $np (Get-PropSafe $u 'salt' ''))
            Save-Database
            Write-Log ('教师重置了 ' + $name + ' 的密码') 'Magenta'
            Send-Json $res @{ success = $true; msg = ('已将 ' + $name + ' 的密码重置成功') }
        }
    # ---------- 教师端：查看学生信箱列表（只读，不改变学生的已读状态） ----------
    'tmails' {
        $s = Get-Session ('' + $b.token) 'teacher'
        if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
        $name = (('' + $b.username).Trim().ToLower() -replace '@.*$', '')
        $u = Find-User $name
        if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
        $box = ('' + $b.box).Trim().ToLower()
        if (@('inbox','starred','sent','draft','junk','trash') -notcontains $box) { $box = 'inbox' }
        $outList = @()
        if ($box -eq 'starred') {
            foreach ($bx in @('inbox','sent','draft','junk')) {
                $lst = AsArray (Get-PropSafe $u.mails $bx @())
                foreach ($m in $lst) {
                    if ([bool](Get-PropSafe $m 'star' $false)) {
                        $mo = Get-MailOut $m $bx
                        $attN = 0
                        try { $attN = (AsArray (Get-PropSafe $m 'attachments' @())).Count } catch { $attN = 0 }
                        Set-Prop $mo 'attCount' $attN
                        $outList += $mo
                    }
                }
            }
        } else {
            $lst = AsArray (Get-PropSafe $u.mails $box @())
            foreach ($m in $lst) {
                $mo = Get-MailOut $m $box
                $attN = 0
                try { $attN = (AsArray (Get-PropSafe $m 'attachments' @())).Count } catch { $attN = 0 }
                Set-Prop $mo 'attCount' $attN
                $outList += $mo
            }
        }
        $outList = @($outList | Sort-Object -Property { $_.time } -Descending)
        Write-Log ('教师查看学生信箱: ' + $name + ' / ' + $box + '（' + $outList.Count + ' 封）') 'Magenta'
        Send-Json $res @{ success = $true; box = $box; mails = $outList; domain = $Script:CurDomain }
    }
    # ---------- 教师端：读取学生单封邮件（只读，绝不标记已读、不写库） ----------
    'tmailread' {
        $s = Get-Session ('' + $b.token) 'teacher'
        if ($null -eq $s) { Send-Json $res @{ success = $false; needLogin = $true; msg = '登录已失效' }; return }
        $name = (('' + $b.username).Trim().ToLower() -replace '@.*$', '')
        $u = Find-User $name
        if ($null -eq $u) { Send-Json $res @{ success = $false; msg = '账号不存在' }; return }
        $box = ('' + $b.box).Trim().ToLower()
        if (@('inbox','starred','sent','draft','junk','trash') -notcontains $box) { Send-Json $res @{ success = $false; msg = '文件夹无效' }; return }
        $mid = ('' + $b.id)
        $item = $null
        $srcBox = ''
        if ($box -eq 'starred') {
            foreach ($bx in @('inbox','sent','draft','junk')) {
                $lst = AsArray (Get-PropSafe $u.mails $bx @())
                foreach ($m in $lst) {
                    if ((('' + (Get-PropSafe $m 'id' '')) -eq $mid) -and [bool](Get-PropSafe $m 'star' $false)) { $item = $m; $srcBox = $bx; break }
                }
                if ($null -ne $item) { break }
            }
        } else {
            $lst = AsArray (Get-PropSafe $u.mails $box @())
            foreach ($m in $lst) {
                if (('' + (Get-PropSafe $m 'id' '')) -eq $mid) { $item = $m; $srcBox = $box; break }
            }
        }
        if ($null -eq $item) { Send-Json $res @{ success = $false; msg = '邮件不存在或已被删除' }; return }
        # ★ 教师只读：不修改 read 状态、不调用 Save-Database
        $mail = Get-MailOut $item $srcBox
        Write-Log ('教师查看学生邮件: ' + $name + ' / ' + $srcBox + ' 「' + (Get-PropSafe $item 'subject' '(无主题)') + '」') 'Magenta'
        Send-Json $res @{ success = $true; mail = $mail; domain = $Script:CurDomain }
    }
        'tlogout' {
            $Script:Sessions.Remove(('' + $b.token)) | Out-Null
            Send-Json $res @{ success = $true; msg = '已退出登录' }
        }

        default {
            Send-Json $res @{ success = $false; msg = ('未知接口: ' + $op) } 404
        }
    }
}

# ----------------------- 请求入口 -------------------------------
function Handle-Request($ctx, [string]$kind) {
    $req = $ctx.Request
    $res = $ctx.Response
    $path = $req.Url.AbsolutePath
    $addr = ''
    try { $addr = $req.RemoteEndPoint.Address.ToString() } catch {}
    #Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $addr + '  ' + $req.HttpMethod + '  ' + $req.Url.PathAndQuery) -ForegroundColor DarkGray
    try {
        if ($req.HasEntityBody -and $req.ContentLength64 -gt 512MB) {
            Send-Json $res @{ success = $false; msg = '请求内容过大' } 413
            return
        }
        if ($path -eq '/' -or $path -eq '/index.html') {
            if ($kind -eq 'student') { Send-File $res (Join-Path $Root 'student.html') }
            else { Send-File $res (Join-Path $Root 'teacher.html') }
            return
        }
        if ($path.StartsWith('/api/')) {
            $op = $path.Substring(5).TrimEnd('/')
            $b = Get-Body $req
            Handle-Api $op $b $res $addr
            return
        }
        Send-Json $res @{ success = $false; msg = '页面或接口不存在' } 404
    } catch {
        try { Send-Json $res @{ success = $false; msg = ('服务器内部错误: ' + $_.Exception.Message) } 500 } catch {}
        Write-Log ('处理请求出错: ' + $_.Exception.Message) 'Red'
    }
}

# ============================ 启 动 ==============================
try { Clear-Host } catch {}
$Host.UI.RawUI.WindowTitle = '易邮 Easymail · 局域网教学邮箱服务器'

Write-Host ''
Write-Host '  ================================================' -ForegroundColor Green
Write-Host '     易邮 Easymail · 局域网教学邮箱服务  v1.6.3' -ForegroundColor Green
Write-Host '  ================================================' -ForegroundColor Green

Load-Database

$_self = New-User '__selftest__' '123456' '自检'
$_s1 = Get-PropSafe $_self 'salt' ''
$_s2 = Get-PropSafe $_self 'passwordHash' ''
if (($_s1 -ne '') -and ($_s2 -ne '') -and ((Get-PwdHash '123456' $_s1) -eq $_s2)) {
    Write-Log '启动自检：新注册对象的密码校验流程通过' 'DarkCyan'
} else {
    Write-Log '启动自检失败！请检查 MailServer.ps1 是否为完整版' 'Red'
}

$cfg0 = Get-ServerSettings
if (('' + (Get-PropSafe $cfg0 'secAnswerHash' '')) -eq '') {
    Write-Log '提醒：教师账号尚未设置密保问题，忘记密码时仅能通过应急码找回（应急码见脚本可配置区）' 'DarkYellow'
}

try {
    if (-not (Get-NetFirewallRule -DisplayName 'EasyMail教学邮箱' -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName 'EasyMail教学邮箱' -Direction Inbound -Action Allow -Protocol TCP -LocalPort ('{0},{1}' -f $StudentPort, $TeacherPort) -ErrorAction Stop | Out-Null
        Write-Log '已自动添加防火墙放行规则（TCP 8899 / 8898）' 'DarkCyan'
    }
} catch {
    Write-Log '防火墙规则未添加，如学生无法访问请手动放行端口' 'DarkYellow'
}

$listenerS = New-Object System.Net.HttpListener
$listenerT = New-Object System.Net.HttpListener
$listenerS.Prefixes.Add('http://+:' + $StudentPort + '/')
$listenerT.Prefixes.Add('http://+:' + $TeacherPort + '/')
try {
    $listenerS.Start()
    $listenerT.Start()
} catch {
    Write-Host ''
    Write-Host ('  [启动失败] 端口 ' + $StudentPort + ' / ' + $TeacherPort + ' 可能被占用，或未以管理员身份运行。') -ForegroundColor Red
    Write-Host '  请使用「启动邮箱服务.bat」启动，或修改脚本顶部可配置区中的端口。' -ForegroundColor Red
    Read-Host '按回车键退出'
    exit 1
}

$ips = @()
try {
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        Select-Object -ExpandProperty IPAddress)
} catch {}
if ($ips.Count -eq 0) {
    try {
        $ips = @([System.Net.Dns]::GetHostAddresses($env:COMPUTERNAME) |
            Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork -and $_.IPAddressToString -notlike '127.*' } |
            ForEach-Object { $_.IPAddressToString })
    } catch {}
}

Write-Host ''
Write-Host ('  学生端(本机)   : http://localhost:' + $StudentPort + '/') -ForegroundColor White
Write-Host ('  教师端(本机)   : http://localhost:' + $TeacherPort + '/') -ForegroundColor White
foreach ($ip in $ips) {
    Write-Host ('  学生端(局域网) : http://' + $ip + ':' + $StudentPort + '/') -ForegroundColor Yellow
    Write-Host ('  教师端(局域网) : http://' + $ip + ':' + $TeacherPort + '/') -ForegroundColor Yellow
}
Write-Host ''
Write-Host ('  邮箱域名: ' + $Script:CurDomain + '（教师后台可改）') -ForegroundColor White
Write-Host ('  教师账号: ' + (Get-PropSafe $cfg0 'teacherUser' 'admin') + '（密码已加密保存；可凭密保问题或应急码找回）') -ForegroundColor White
Write-Host ('  注册规则: 图形验证码=' + (Get-PropSafe $cfg0 'regCaptcha' $true) + '  虚拟短信=' + (Get-PropSafe $cfg0 'regSmsCode' $false) + '  密码复杂度=' + (Get-PropSafe $cfg0 'pwdComplexity' 0)) -ForegroundColor White
Write-Host '  完整功能: 转发/定时发送(3秒扫描)/自定义分类箱(可加密)/黑名单' -ForegroundColor White
Write-Host ('  批量导入: 支持 xlsx/xls/csv，默认密码 ' + $ImportDefaultPwd + '，单次上限 ' + $ImportMaxRows + ' 行') -ForegroundColor Yellow
Write-Host ''
Write-Host ('  数据文件(加密): ' + $DataFile) -ForegroundColor White
Write-Host ('  运行日志(明文): ' + $LogFile) -ForegroundColor White
Write-Host ''
Write-Host ('  邮件服务正常运行中……') -ForegroundColor Yellow
Write-Host ''

try { Start-Process ('http://localhost:' + $StudentPort + '/') } catch {}
try { Start-Process ('http://localhost:' + $TeacherPort + '/') } catch {}

$taskS = $listenerS.GetContextAsync()
$taskT = $listenerT.GetContextAsync()
Write-Log '服务已启动，等待请求...' 'DarkGreen'

try {
    while ($true) {
        $idx = [System.Threading.WaitHandle]::WaitAny(@($taskS.AsyncWaitHandle, $taskT.AsyncWaitHandle), 3000)
        try {
            if ($idx -eq 0) {
                $ctx = $taskS.Result
                $taskS = $listenerS.GetContextAsync()
                Handle-Request $ctx 'student'
            } elseif ($idx -eq 1) {
                $ctx = $taskT.Result
                $taskT = $listenerT.GetContextAsync()
                Handle-Request $ctx 'teacher'
            }
        } catch {
            Write-Log ('监听异常: ' + $_.Exception.Message) 'Red'
            Start-Sleep -Milliseconds 300
            try { if ($listenerS.IsListening -and $taskS.IsCompleted -and $taskS.IsFaulted) { $taskS = $listenerS.GetContextAsync() } } catch {}
            try { if ($listenerT.IsListening -and $taskT.IsCompleted -and $taskT.IsFaulted) { $taskT = $listenerT.GetContextAsync() } } catch {}
        }
        try { Invoke-ScheduledMails } catch {
            Write-Log ('定时任务检查异常: ' + $_.Exception.Message) 'Red'
        }
    }
} finally {
    try { $listenerS.Stop() } catch {}
    try { $listenerT.Stop() } catch {}
    Write-Log '服务已停止' 'Yellow'
}
