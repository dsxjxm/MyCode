@echo off
chcp 65001 >nul
title 易邮 Easymail - 首次配置防火墙

rem :: ===== 自提权：双击即弹 UAC，无需手动右键 =====
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 正在请求管理员权限，请在弹窗中点击"是"...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo ================================================
echo   易邮 Easymail - 防火墙与 URL 一次性配置
echo ================================================
echo.

rem :: ---- 学生端 8899 ----
set PORT=8899
netsh http add urlacl url=http://+:%PORT%/ user=Everyone >nul 2>&1
netsh advfirewall firewall delete rule name="EasyMail教学邮箱" >nul 2>&1
netsh advfirewall firewall add rule name="EasyMail教学邮箱" dir=in action=allow protocol=TCP localport=%PORT% >nul 2>&1
echo [OK] 学生端端口 %PORT% 已放行

rem :: ---- 教师端 8898 ----
set PORT=8898
netsh http add urlacl url=http://+:%PORT%/ user=Everyone >nul 2>&1
netsh advfirewall firewall delete rule name="EasyMail教学邮箱2" >nul 2>&1
netsh advfirewall firewall add rule name="EasyMail教学邮箱2" dir=in action=allow protocol=TCP localport=%PORT% >nul 2>&1
echo [OK] 教师端端口 %PORT% 已放行

echo.
echo 配置完成！
echo.

title 易邮 Easymail · 局域网教学邮箱服务

rem ============ 自动为 PowerShell 脚本补 UTF-8 BOM，防止中文乱码 ============
powershell -NoProfile -Command "$p='%~dp0MailServer.ps1';if(Test-Path $p){$b=[IO.File]::ReadAllBytes($p);if($b.Length -lt 3 -or $b[0] -ne 0xEF -or $b[1] -ne 0xBB -or $b[2] -ne 0xBF){[IO.File]::WriteAllBytes($p,[byte[]](0xEF,0xBB,0xBF)+$b)}}"

cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "MailServer.ps1"

echo.
echo [提示] 服务已停止。
pause
