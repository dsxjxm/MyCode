@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem ===== 可修改配置 =====
set "PORT=3000"
set "DATA_DIR=%~dp0data"
set "UV_THREADPOOL_SIZE=8"
rem ======================

if not exist "dist\server\server.cjs" goto no_dist

set "NODE_EXE=node-x64.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" set "NODE_EXE=node-x86.exe"
if not exist "%NODE_EXE%" set "NODE_EXE=node-x64.exe"
if not exist "%NODE_EXE%" set "NODE_EXE=node-x86.exe"
if not exist "%NODE_EXE%" goto no_node

echo.
echo  局域网仿真实训教学平台 v0.3.1 正在启动（%NODE_EXE%）...
echo  数据目录：%DATA_DIR%
echo  关闭本窗口即停止服务
echo.

"%NODE_EXE%" "dist\server\server.cjs"

echo.
echo  服务已退出，错误码：%ERRORLEVEL%
echo.
pause
exit /b 0

:no_node
echo.
echo  未找到 node-x64.exe / node-x86.exe，请确认压缩包已完整解压。
echo.
pause
exit /b 1

:no_dist
echo.
echo  未找到 dist\server\server.cjs。
echo  请先把压缩包完整解压到文件夹，再双击 启动.bat。
echo.
pause
exit /b 1
