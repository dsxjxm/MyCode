@echo off
chcp 65001 >nul
cd /d %~dp0
if not exist node.exe (
  echo [错误] 未找到 node.exe
  echo 请确认本压缩包完整解压，或将 Node.js 14 的 node.exe 放到本目录
  pause
  exit /b 1
)
if not defined PORT set PORT=3000
echo 正在启动局域网仿真实训教学平台...
echo 本机访问：http://localhost:%PORT%
node.exe server\index.js
echo.
echo 服务已停止。
pause
