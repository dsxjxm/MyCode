const who = document.getElementById('who');
const btn = document.getElementById('btn');
const msg = document.getElementById('msg');

// 试试修改这里，点击保存后右边会立即刷新
who.textContent = '世界';

btn.addEventListener('click', () => {
  msg.textContent = '按钮点击成功！现在你可以修改 CSS 和 JS 了。';
});
