# 局域网仿真实训教学平台

浏览器/服务器（B/S）架构的局域网仿真实训教学平台，面向职业院校课堂实训。

技术栈：**Node.js + Express + SQLite（sql.js WASM，零原生依赖）+ 原生前端**，无构建步骤、离线可用，`npm start` 一键启动。

已上线四个实训模块：

| 模块 | 内容 |
| --- | --- |
| WWW / IIS 站点 | 文件空间管理、分屏代码编辑器、实时预览、站点设置（默认文档、MIME、访问日志）、HTML/CSS/JS 语法速查悬浮面板（可拖拽/收起、搜索、一键插入） |
| FTP / Telnet 终端 | 命令行模拟、目录浏览、上传下载、FTP 账号与空间管理 |
| DNS / DHCP 网络模拟 | SVG 拓扑画布、PC 拖放、DHCP 地址池分配、DNS 记录解析、ipconfig/ping/nslookup/tracert/arp/netsh 命令模拟 |
| 邮件服务器 SMTP / POP3 | 邮箱注册（别名、图形验证码、模拟短信）、密码/短信登录、收发邮件、附件、富文本、通讯簿、黑名单、定时发送、SMTP/POP3 协议日志 |

---

## 一、环境要求

| 项目 | 要求 |
| --- | --- |
| 操作系统 | Windows / macOS / Linux |
| Node.js | **>= 20.0.0**（推荐 20 LTS 或 22 LTS） |
| 浏览器 | Chrome / Edge / Firefox 最新版 |

> 查看版本：`node -v`。安装包下载：<https://nodejs.org/>

---

## 二、本地部署流程

### 1. 解压

把压缩包解压到任意目录，例如 `D:\lan-sim\`。

### 2. 安装依赖

在该目录打开终端（Windows：文件夹地址栏输入 `cmd` 回车）：

```bash
npm install
```

> 首次安装需联网。若网络较慢，可先执行
> `npm config set registry https://registry.npmmirror.com` 再安装。

### 3. 启动

```bash
npm start
```

看到如下输出即启动成功：

```
局域网仿真实训教学平台 已启动
本机访问：http://localhost:3000
局域网访问：http://192.168.x.x:3000
教师初始账号：admin / admin123
```

浏览器打开 <http://localhost:3000>，自动进入登录页。

### 4. 停止

在运行终端按 `Ctrl + C`。

---

## 三、默认账号

| 角色 | 账号 | 密码 | 说明 |
| --- | --- | --- | --- |
| 教师 | `admin` | `admin123` | 班级/学生管理、通知、四模块管理 |
| 学生 | `20250101` | `123456` | 张三（演示） |
| 学生 | `20250102` | `123456` | 李四（演示） |
| 学生 | `20250103` | `123456` | 王五（演示） |
| 教师邮箱 | `teacher@example.local` | `123456` | 可在邮件模块「邮箱别名注册」中修改 |

首次启动自动创建演示班级、3 名学生与上述邮箱账号，无需额外初始化。

> 学生首次进入邮件模块需完成「注册邮箱」（绑定学生账号、自选别名、模拟短信验证码），之后即可收发邮件。
> 模拟短信不会真的发送，验证码会显示在页面右下角的模拟手机短信弹窗中。

---

## 四、目录说明

```
.
├── server/              # 后端
│   ├── index.js         # 入口（端口、路由挂载、启动任务）
│   ├── db.js            # 建表、迁移与演示数据 seed
│   ├── paths.js         # 数据目录定位
│   ├── services/        # 业务模拟（WWW/FTP/DNS-DHCP/邮件等）
│   └── routes/          # HTTP 接口
├── public/              # 前端页面与静态资源（无构建）
├── scripts/             # 辅助脚本
├── test/                # 单元测试（npm test）
├── data/                # 运行时数据（自动生成，勿删）
└── package.json
```

### 数据保存位置

- 默认：项目下的 `data/` 目录（`platform.db`、学生文件空间、邮件附件等）
- 如该目录不可写，自动回退到系统临时目录 `lan-sim-data`
- 也可自定义：

```bash
# Windows
set DATA_DIR=D:\lan-sim-data && npm start

# macOS / Linux
DATA_DIR=/opt/lan-sim-data npm start
```

> 删除 `data/` 相当于重置平台（演示数据会在下次启动时重新生成）。

---

## 五、局域网内学生访问

启动日志中的「局域网访问」地址即学生访问地址（如 `http://192.168.1.100:3000`）。

- 学生电脑需与教师机在同一局域网
- 打不开时检查教师机防火墙是否放行 3000 端口
- 修改端口：

```bash
# Windows
set PORT=8080 && npm start

# macOS / Linux
PORT=8080 npm start
```

---

## 六、其它命令

```bash
npm test       # 运行单元测试
npm run dev    # 开发模式（后端改动自动重启）
```

---

## 七、常见问题

**1. 端口被占用**
换端口启动：`PORT=8080 npm start`（Windows 用 `set PORT=8080 && npm start`）。

**2. 启动报 Cannot find module**
未安装依赖或安装不完整，重新执行 `npm install`。

**3. 数据想恢复初始状态**
停止服务，删除 `data/` 目录后重新 `npm start`。

**4. 学生邮件验证码在哪里看**
点击「获取验证码」后，页面右下角会弹出模拟手机短信，显示 6 位验证码，可点「一键填入」。

**5. 教师如何关闭学生编辑网络配置**
教师控制台 →「模块管理」→ 网络模拟卡片中的开关「允许学生编辑 DHCP / DNS / PC 配置」。

---

## 八、Windows 7 / 8 离线版（免安装 Node）

Windows 7 无法运行 Node 14 及以上版本（会报 `无法定位程序输入点 GetHostNameW`）。为此单独提供了离线版压缩包：

- **Win7 离线版**：内置 Node 12.22.12 的 64 位与 32 位运行环境（`node-x64.exe` / `node-x86.exe`），`启动.bat` 按系统架构自动选择
- **Win8 离线版**：内置 Node 14.21.3 的 64 位与 32 位运行环境，其余用法相同
- 后端已用 esbuild 打包为单个 `dist\server\server.cjs`，无需 npm install、无需联网
- 要求：Windows 7 **SP1** / Windows 8 / 8.1；建议装齐补丁，至少 KB2999226（UCRT）、KB4474419 / KB4490628（SHA-2）
- 浏览器：Chrome / Edge 最高 109 版（Win7、Win8.1），或 360 极速浏览器、Firefox 115 ESR
- 使用：解压后双击 `启动.bat`，访问 `http://localhost:3000`；数据保存在 `data\`（由启动脚本指定 `DATA_DIR`）
- `sql.js` 固定为 `1.12.0`（1.13 及以上的 wasm 在 Node 12 下会报 `wasm function signature contains illegal type`）

---

## 九、并发与性能（60 人班级）

软件侧的三个瓶颈已针对性优化：

1. **登录密码校验改为异步**：`verifyPasswordAsync` 用 `crypto.scrypt` 回调版走 libuv 线程池，多人同时登录不再串行卡住事件循环；`UV_THREADPOOL_SIZE=8`（启动脚本已设置）
2. **数据库落盘改为合并写**：sql.js 是内存库，原先每次写都整库导出并覆盖文件；现在 250ms 内的多次写合并为一次落盘（退出/中断前强制 flush，最多丢 250ms 写入），并发写不再互相排队
3. **HTTP 长连接调优**：`keepAliveTimeout=65s`、`headersTimeout=66s`，避免局域网浏览器复用连接时出现 `ECONNRESET`
4. **登录限流排队**：同一时刻的密码校验并发超过阈值（默认 6，可用 `LOGIN_MAX_CONCURRENT` 调整）时，服务端立即返回 `202` 并给出建议重试间隔，登录页显示“请稍候”并自动重试，避免瞬时登录把线程池打满

压测脚本：`scripts/loadtest.mjs`（零依赖，兼容 Node 12+）

```bash
node scripts/loadtest.mjs --base http://127.0.0.1:3000 \
  --accounts 20250101,20250102,20250103 \
  --stages 20:30,40:30,60:30 --think 1000-2500 --write 30
```

参数：`--stages 并发:秒`、`--think 最小-最大毫秒`、`--write 写占比%`、`--pid`/`--db`（Linux 下统计内存与库大小）。

建议课堂开场分批登录（30+30，间隔 1~2 分钟）；Windows 上把程序目录与 `data` 加入 Defender 排除项、关闭磁盘索引、用 SSD，可明显降低写库与文件操作延迟。

---

## 十、运行监控与学期归档（v0.3.0）

教师控制台左侧新增两个入口，均需教师身份：

### 运行监控

- **在线人数**：近 3 分钟内有请求活动的教师 / 学生数量，并列出用户与最近活动时间
- **负载**：进程内存、CPU 使用率、系统 1/5/15 分钟负载、运行时长、数据库文件大小
- **请求质量**：近 60 秒每秒请求数、平均 / P95 / P99 延迟、5xx 错误数
- **慢请求**：耗时 ≥ 500ms 的请求（方法、路径、耗时、状态、用户），可据此定位卡顿接口
- **登录排队**：当前排队人数、并发上限与累计限流次数

默认每 3 秒自动刷新，可暂停或手动刷新；数据来自进程内统计接口 `GET /api/admin/metrics`，不依赖外部监控组件。

### 学期归档

- 一键把当前内存数据库落盘并复制为 `data/archives/archive-<时间>-<学期>.db` 快照
- 可选「归档后清理邮件」（清空收件/发件/草稿/定时任务与附件）与「清空回收站」
- 归档先于清理执行，因此归档文件始终包含清理前的完整数据
- 列表中可直接下载或删除归档文件

> 归档接口：`GET/POST /api/admin/archives`、`GET /api/admin/archives/:name/download`、`DELETE /api/admin/archives/:name`

---

## 十一、版本迭代

版本号集中在 [server/version.js](file:///workspace/server/version.js)，发版时同步修改该文件与 `package.json`：

- 服务端：`GET /api/version` 返回 `{ name, version, build }`，`GET /health` 也带 `version`
- 页面：登录页左下角、教师控制台与学生实训页右上角显示 `v0.3.0` 角标（读取 `/api/version`）
- 打包文件名带版本号，便于区分历史离线包

| 版本 | 日期 | 内容 |
| --- | --- | --- |
| v0.3.0 | 2026-11-27 | 新增「运行监控」面板（在线人数 / CPU 负载 / P95 延迟 / 慢请求 / 登录排队）；新增「学期归档」一键数据库快照（可清理邮件与回收站、支持下载/删除）；登录限流：并发超阈值自动排队并提示“请稍候”，前端自动重试 |
| v0.2.0 | 2026-11-27 | 并发优化：密码校验异步化（scrypt 线程池）、数据库 250ms 合并落盘、HTTP 长连接调优；新增版本接口与页面版本标识；WWW 语法速查面板；上传中文文件名修复（含历史文件自动修正） |
| v0.1.0 | 2026-11-26 | 首个可部署版本：WWW / FTP / Telnet / DNS / DHCP / 邮件六大模块 |

